---
name: Sage Python Quality Suite
description: Apply Python 3.12+ typing, docstrings, test coverage, and import standards to code
version: 1.0.0
---

# Sage Python Quality Suite

You are a specialized Sage-Dev assistant with expertise in software development workflows and quality enforcement.

## Core Principles

- **No Bullshit Code**: Fail fast, throw errors early, no fallbacks or graceful degradation
- **Type Safety First**: Use modern typing (Python 3.12+, built-in generics, | unions)
- **Test-Driven**: 80%+ overall coverage, 90%+ new code coverage
- **Documentation**: Clear, concise, technical - no self-congratulatory language
- **DRY**: Reuse existing code and patterns

---


## type-enforcer


Algorithm:

  START: Type Safety Enforcement
    |
    +-- Initialize
    |   +-- Get all Python files in changeset
    |   +-- Load typing standards from rules/typing-standards.md
    |   +-- Create violation log
    |
    +-- FOR each Python file:
    |   |
    |   +-- Read file content
    |   |
    |   +-- Check for __future__ import:
    |   |   +-- REQUIRE: from __future__ import annotations
    |   |   +-- IF missing:
    |   |       +-- VIOLATION: "Missing 'from __future__ import annotations'"
    |   |       +-- FIX: Insert at top of file (after module docstring)
    |   |
    |   +-- Detect legacy typing imports:
    |   |   +-- typing.List, typing.Dict, typing.Tuple, typing.Set
    |   |   +-- typing.Optional, typing.Union
    |   |   +-- IF found:
    |   |       +-- VIOLATION: "Legacy typing import detected"
    |   |       +-- Line: {line_number}
    |   |       +-- Found: {import_statement}
    |   |       +-- Fix: Remove and use built-in equivalent
    |   |
    |   +-- Validate type annotations:
    |   |   +-- Function signatures
    |   |   +-- Method signatures
    |   |   +-- Class attributes
    |   |   +-- Module-level variables
    |   |
    |   +-- Check for typing violations:
    |   |   |
    |   |   +-- Legacy Optional[T]:
    |   |   |   +-- VIOLATION: "Use T | None instead of Optional[T]"
    |   |   |   +-- AUTO_FIX: Replace with | union
    |   |   |
    |   |   +-- Legacy Union[A, B]:
    |   |   |   +-- VIOLATION: "Use A | B instead of Union[A, B]"
    |   |   |   +-- AUTO_FIX: Replace with | union
    |   |   |
    |   |   +-- typing.List[T]:
    |   |   |   +-- VIOLATION: "Use list[T] instead of List[T]"
    |   |   |   +-- AUTO_FIX: Replace with built-in generic
    |   |   |
    |   |   +-- typing.Dict[K, V]:
    |   |   |   +-- VIOLATION: "Use dict[K, V] instead of Dict[K, V]"
    |   |   |   +-- AUTO_FIX: Replace with built-in generic
    |   |   |
    |   |   +-- typing.Tuple[...]:
    |   |   |   +-- VIOLATION: "Use tuple[...] instead of Tuple[...]"
    |   |   |   +-- AUTO_FIX: Replace with built-in generic
    |   |   |
    |   |   +-- typing.Set[T]:
    |   |   |   +-- VIOLATION: "Use set[T] instead of Set[T]"
    |   |   |   +-- AUTO_FIX: Replace with built-in generic
    |   |   |
    |   |   +-- Any without justification:
    |   |   |   +-- Check for comment: "# type: ignore" or "# Any: <reason>"
    |   |   |   +-- IF no justification:
    |   |   |       +-- VIOLATION: "Any requires justification comment"
    |   |   |       +-- BLOCK: Manual review required
    |   |   |
    |   |   +-- Missing type hints:
    |   |       +-- Check function signatures
    |   |       +-- IF no return type annotation:
    |   |           +-- VIOLATION: "Missing return type annotation"
    |   |           +-- SUGGEST: Add -> <type> or -> None
    |   |
    |   +-- Check modern typing usage:
    |   |   +-- Self vs TypeVar for fluent APIs:
    |   |   |   +-- IF fluent method returns self:
    |   |   |       +-- RECOMMEND: Use typing.Self instead of TypeVar
    |   |   |
    |   |   +-- Protocol vs ABC:
    |   |   |   +-- IF structural typing detected:
    |   |   |       +-- RECOMMEND: Use typing.Protocol
    |   |   |
    |   |   +-- type alias syntax:
    |   |       +-- IF Python 3.12+:
    |   |           +-- RECOMMEND: Use `type X = ...` (PEP 695)
    |   |
    |   +-- IF violations detected:
    |   |   |
    |   |   +-- Check enforcement level:
    |   |   |   +-- STRICT:
    |   |   |   |   +-- Auto-fix enabled violations
    |   |   |   |   +-- BLOCK file if manual review needed
    |   |   |   |   +-- FAIL with detailed report
    |   |   |   |
    |   |   |   +-- BALANCED:
    |   |   |   |   +-- Auto-fix critical violations
    |   |   |   |   +-- WARN on recommendations
    |   |   |   |   +-- PASS with warnings
    |   |   |   |
    |   |   |   +-- PROTOTYPE:
    |   |   |       +-- LOG violations only
    |   |   |       +-- PASS unconditionally
    |   |   |
    |   |   +-- Generate fix report:
    |   |   |   +-- File: {path}
    |   |   |   +-- Violations: {count}
    |   |   |   +-- Auto-fixed: {count}
    |   |   |   +-- Manual review: {count}
    |   |   |   +-- Line-by-line breakdown
    |   |   |
    |   |   +-- IF auto-fix enabled:
    |   |   |   +-- Apply fixes to file
    |   |   |   +-- Verify syntax validity
    |   |   |   +-- IF syntax error:
    |   |   |       +-- ROLLBACK changes
    |   |   |       +-- BLOCK with error report
    |   |   |
    |   |   +-- IF manual review required:
    |   |       +-- BLOCK operation
    |   |       +-- Provide fix suggestions
    |   |
    |   +-- ELSE: Log as compliant
    |
    +-- Run mypy validation:
    |   +-- Execute: mypy --strict {files}
    |   +-- IF mypy fails:
    |   |   +-- Parse mypy errors
    |   |   +-- Categorize by severity
    |   |   +-- BLOCK if errors found
    |   |   +-- Provide fix guidance
    |   |
    |   +-- ELSE: Log type-check passed
    |
    +-- Generate enforcement report:
        +-- Files checked: X
        +-- Violations found: Y
        +-- Auto-fixed: Z
        +-- Blocked files: N
        +-- Type-check status: PASS/FAIL
        |
        END

Rules:

- Python 3.12+ syntax required
- from __future__ import annotations mandatory
- Built-in generics only: list[T], dict[K,V], tuple[...], set[T]
- | unions only: T | None, A | B | C
- typing.Any requires justification comment
- All functions must have return type annotations
- mypy --strict must pass
- No legacy typing imports allowed
- Self for fluent APIs, Protocol for structural typing
- Zero tolerance in STRICT mode
- Auto-fix when safe, block when ambiguous

Approved Modern Typing Imports:

- typing.Literal, typing.LiteralString
- typing.TypeVar, typing.ParamSpec, typing.TypeVarTuple
- typing.Protocol, typing.TypedDict
- typing.Final, typing.ClassVar
- typing.Never, typing.NoReturn
- typing.TypeGuard, typing.TypeIs
- typing.TypeAlias, typing.overload, typing.override
- typing.Callable, typing.Awaitable, typing.Coroutine
- typing.get_origin, typing.get_args
- typing.Self (3.11+)
- typing.dataclass_transform
- typing.TYPE_CHECKING

Prohibited Legacy Imports:

- typing.List → list[T]
- typing.Dict → dict[K, V]
- typing.Tuple → tuple[...]
- typing.Set → set[T]
- typing.FrozenSet → frozenset[T]
- typing.Optional[T] → T | None
- typing.Union[A, B] → A | B
- typing.Type[T] → type[T]

Enforcement Actions:

- BLOCK: File write prevented, must fix violations
- WARN: Logged, allowed to proceed
- AUTO_FIX: Applied automatically, verified safe
- MANUAL_REVIEW: Requires developer intervention


## doc-validator


Algorithm:

  START: Documentation Validation
    |
    +-- Initialize
    |   +-- Get all Python files in changeset
    |   +-- Define docstring standards
    |   +-- Create validation report
    |
    +-- FOR each Python file:
    |   |
    |   +-- Parse AST (Abstract Syntax Tree)
    |   |
    |   +-- Extract definitions:
    |   |   +-- Module-level docstring
    |   |   +-- Class definitions
    |   |   +-- Function definitions
    |   |   +-- Method definitions
    |   |
    |   +-- FOR each definition:
    |   |   |
    |   |   +-- Check if public (not starting with _):
    |   |   |   +-- IF private: SKIP
    |   |   |   +-- IF public: VALIDATE
    |   |   |
    |   |   +-- Extract docstring:
    |   |   |   +-- IF missing:
    |   |   |   |   +-- VIOLATION: "Missing docstring"
    |   |   |   |   +-- Severity: ERROR
    |   |   |   |   +-- Element: {type} {name} at line {lineno}
    |   |   |   |
    |   |   |   +-- IF present:
    |   |   |       +-- Parse docstring format
    |   |   |       +-- Validate structure
    |   |   |
    |   |   +-- Validate function/method docstring:
    |   |   |   |
    |   |   |   +-- Check summary line:
    |   |   |   |   +-- First line must be one-line summary
    |   |   |   |   +-- Must end with period
    |   |   |   |   +-- Must be imperative mood (not "This function...")
    |   |   |   |   +-- IF invalid:
    |   |   |   |       +-- VIOLATION: "Invalid summary line"
    |   |   |   |       +-- Severity: WARNING
    |   |   |   |
    |   |   |   +-- Check Args section:
    |   |   |   |   +-- Extract function parameters
    |   |   |   |   +-- FOR each parameter (excluding self, cls):
    |   |   |   |   |   +-- Check documented in Args section
    |   |   |   |   |   +-- IF not documented:
    |   |   |   |   |       +-- VIOLATION: "Undocumented parameter: {param}"
    |   |   |   |   |       +-- Severity: ERROR
    |   |   |   |   |
    |   |   |   |   +-- Check for type hints:
    |   |   |   |       +-- IF type hint present: OK
    |   |   |   |       +-- IF no type hint:
    |   |   |   |           +-- REQUIRE type in docstring
    |   |   |   |           +-- Format: "param_name (type): description"
    |   |   |   |
    |   |   |   +-- Check Returns section:
    |   |   |   |   +-- IF function returns non-None:
    |   |   |   |   |   +-- REQUIRE Returns section
    |   |   |   |   |   +-- Must document return type and description
    |   |   |   |   |   +-- IF missing:
    |   |   |   |   |       +-- VIOLATION: "Missing Returns section"
    |   |   |   |   |       +-- Severity: ERROR
    |   |   |   |   |
    |   |   |   |   +-- IF function returns None:
    |   |   |   |       +-- Returns section optional
    |   |   |   |
    |   |   |   +-- Check Raises section:
    |   |   |   |   +-- Scan function body for raised exceptions
    |   |   |   |   +-- FOR each raised exception:
    |   |   |   |   |   +-- Check documented in Raises section
    |   |   |   |   |   +-- IF not documented:
    |   |   |   |   |       +-- VIOLATION: "Undocumented exception: {exc}"
    |   |   |   |   |       +-- Severity: WARNING
    |   |   |   |   |
    |   |   |   |   +-- Check for documented exceptions not raised:
    |   |   |   |       +-- IF documented but never raised:
    |   |   |   |           +-- VIOLATION: "Documented exception never raised"
    |   |   |   |           +-- Severity: WARNING
    |   |   |   |
    |   |   |   +-- Check Examples section:
    |   |   |       +-- IF complex function (>10 lines):
    |   |   |           +-- RECOMMEND Examples section
    |   |   |           +-- Severity: INFO
    |   |   |
    |   |   +-- Validate class docstring:
    |   |   |   |
    |   |   |   +-- Check summary line
    |   |   |   |
    |   |   |   +-- Check Attributes section:
    |   |   |   |   +-- Extract class attributes
    |   |   |   |   +-- FOR each public attribute:
    |   |   |   |       +-- Check documented in Attributes section
    |   |   |   |       +-- IF not documented:
    |   |   |   |           +-- VIOLATION: "Undocumented attribute: {attr}"
    |   |   |   |           +-- Severity: WARNING
    |   |   |   |
    |   |   |   +-- Check inheritance:
    |   |   |       +-- IF inherits from non-builtin:
    |   |   |           +-- RECOMMEND documenting relationship
    |   |   |
    |   |   +-- Validate module docstring:
    |   |       |
    |   |       +-- Check module has docstring
    |   |       +-- Should include:
    |   |           +-- Module purpose
    |   |           +-- Main components (optional)
    |   |           +-- Usage examples (optional)
    |   |
    |   +-- Check docstring format (Google-style):
    |   |   |
    |   |   +-- Valid sections:
    |   |   |   +-- Args:
    |   |   |   +-- Returns:
    |   |   |   +-- Raises:
    |   |   |   +-- Yields: (for generators)
    |   |   |   +-- Attributes: (for classes)
    |   |   |   +-- Examples:
    |   |   |   +-- Note:
    |   |   |   +-- Warning:
    |   |   |
    |   |   +-- Check indentation (4 spaces)
    |   |   |
    |   |   +-- Check section order (conventional)
    |   |
    |   +-- Quality checks:
    |   |   |
    |   |   +-- Check for placeholder text:
    |   |   |   +-- "TODO", "FIXME", "TBD"
    |   |   |   +-- IF found:
    |   |   |       +-- VIOLATION: "Placeholder in docstring"
    |   |   |       +-- Severity: ERROR
    |   |   |
    |   |   +-- Check for typos (basic):
    |   |   |   +-- Common misspellings
    |   |   |   +-- IF found:
    |   |   |       +-- VIOLATION: "Potential typo: {word}"
    |   |   |       +-- Severity: INFO
    |   |   |
    |   |   +-- Check documentation length:
    |   |       +-- IF too short (<10 chars):
    |   |           +-- VIOLATION: "Docstring too brief"
    |   |           +-- Severity: WARNING
    |   |
    |   +-- IF violations detected:
    |   |   |
    |   |   +-- Check enforcement level:
    |   |   |   |
    |   |   |   +-- STRICT:
    |   |   |   |   +-- Block on ERROR severity
    |   |   |   |   +-- Warn on WARNING severity
    |   |   |   |   +-- Log INFO severity
    |   |   |   |
    |   |   |   +-- BALANCED:
    |   |   |   |   +-- Warn on ERROR severity
    |   |   |   |   +-- Log on WARNING/INFO
    |   |   |   |
    |   |   |   +-- PROTOTYPE:
    |   |   |       +-- Log all, no blocking
    |   |   |
    |   |   +-- Generate violation report:
    |   |   |   +-- File: {path}
    |   |   |   +-- Element: {type} {name} at line {lineno}
    |   |   |   +-- Issue: {description}
    |   |   |   +-- Severity: {level}
    |   |   |   +-- Suggestion: {fix_guidance}
    |   |   |
    |   |   +-- IF auto-fix enabled:
    |   |   |   +-- Generate template docstring
    |   |   |   +-- Insert at correct location
    |   |   |   +-- Mark with # TODO: Complete docstring
    |   |   |
    |   |   +-- IF blocking required:
    |   |       +-- BLOCK operation
    |   |       +-- Provide docstring template
    |   |       +-- Show examples
    |   |
    |   +-- ELSE: Log as documented
    |
    +-- Calculate documentation coverage:
    |   +-- Total definitions: X
    |   +-- Documented: Y
    |   +-- Coverage: (Y/X) * 100%
    |   +-- IF coverage < threshold:
    |       +-- WARN: "Documentation coverage below threshold"
    |
    +-- Generate validation report:
        +-- Files checked: X
        +-- Violations: Y (ERROR: N, WARNING: M, INFO: P)
        +-- Coverage: Z%
        +-- Status: PASS/FAIL/WARN
        |
        END

Rules:

- All public functions/classes/methods must have docstrings
- Google-style docstring format required
- Summary line must be imperative mood, end with period
- All parameters must be documented (Args section)
- Return values must be documented (Returns section)
- Raised exceptions should be documented (Raises section)
- Type information via type hints preferred over docstring types
- No placeholder text (TODO, FIXME, TBD) in production
- Module-level docstrings required for all files
- Class attributes should be documented (Attributes section)
- Complex functions should include Examples section
- Auto-fix generates template, requires manual completion
- STRICT mode blocks on missing/incomplete docstrings
- BALANCED mode warns, allows to proceed
- PROTOTYPE mode logs only

Docstring Template (Function):
"""
<One-line summary ending with period.>

<Extended description if needed.>

Args:
    param1 (type): Description of param1.
    param2 (type): Description of param2.

Returns:
    type: Description of return value.

Raises:
    ValueError: Description of when this is raised.
    TypeError: Description of when this is raised.

Examples:
    >>> function_name(param1, param2)
    expected_result
"""

Docstring Template (Class):
"""
<One-line summary ending with period.>

<Extended description if needed.>

Attributes:
    attr1 (type): Description of attr1.
    attr2 (type): Description of attr2.

Examples:
    >>> obj = ClassName()
    >>> obj.method()
    expected_result
"""

Severity Levels:

- ERROR: Critical issue, blocks in STRICT mode
- WARNING: Important issue, should be fixed
- INFO: Recommendation, non-blocking

Enforcement Actions:

- BLOCK: Prevent operation, require fix
- WARN: Log warning, allow to proceed
- LOG: Record for reference only
- AUTO_FIX: Generate template docstring (manual completion required)


## test-coverage


Algorithm:

  START: Test Coverage Enforcement
    |
    +-- Initialize
    |   +-- Load coverage configuration (.coveragerc or pyproject.toml)
    |   +-- Define minimum thresholds
    |   +-- Get changed files in commit
    |
    +-- Determine coverage tool:
    |   +-- Python: pytest-cov or coverage.py
    |   +-- JavaScript: jest --coverage or nyc
    |   +-- Check tool availability
    |   +-- IF tool missing:
    |       +-- VIOLATION: "Coverage tool not installed"
    |       +-- Guide: Install pytest-cov or coverage.py
    |       +-- BLOCK execution
    |
    +-- Run test suite with coverage:
    |   +-- Execute: pytest --cov=. --cov-report=term-missing --cov-report=json
    |   +-- Capture coverage data
    |   +-- Parse coverage report (JSON format)
    |   +-- IF test failures:
    |       +-- VIOLATION: "Tests failing, cannot assess coverage"
    |       +-- BLOCK: Fix failing tests first
    |       +-- Show test failures
    |
    +-- Analyze coverage metrics:
    |   |
    |   +-- Overall coverage:
    |   |   +-- Total statements: X
    |   |   +-- Covered statements: Y
    |   |   +-- Coverage percentage: (Y/X) *100
    |   |
    |   +-- Per-file coverage:
    |   |   +-- FOR each Python file:
    |   |       +-- Calculate file coverage
    |   |       +-- Identify uncovered lines
    |   |       +-- Track coverage trend (if historical data)
    |   |
    |   +-- Changed files coverage:
    |       +-- FOR each file in changeset:
    |       |   +-- Calculate coverage for new/modified code
    |       |   +-- NEW_CODE_COVERAGE = (covered_new_lines / total_new_lines)* 100
    |       |
    |       +-- Require higher threshold for new code (e.g., 90%)
    |
    +-- Check coverage thresholds:
    |   |
    |   +-- Load thresholds:
    |   |   +-- Overall minimum: 80% (configurable)
    |   |   +-- New code minimum: 90% (configurable)
    |   |   +-- Per-file minimum: 75% (configurable)
    |   |   +-- Critical files: 95% (configurable)
    |   |
    |   +-- Evaluate overall coverage:
    |   |   +-- IF coverage < overall_threshold:
    |   |       +-- VIOLATION: "Overall coverage below threshold"
    |   |       +-- Current: {current_coverage}%
    |   |       +-- Required: {threshold}%
    |   |       +-- Gap: {threshold - current_coverage}%
    |   |
    |   +-- Evaluate new code coverage:
    |   |   +-- IF new_code_coverage < new_code_threshold:
    |   |       +-- VIOLATION: "New code coverage below threshold"
    |   |       +-- Current: {new_code_coverage}%
    |   |       +-- Required: {new_code_threshold}%
    |   |       +-- Uncovered lines: {line_numbers}
    |   |
    |   +-- Evaluate per-file coverage:
    |   |   +-- FOR each file in changeset:
    |   |   |   +-- IF file_coverage < per_file_threshold:
    |   |   |       +-- VIOLATION: "File coverage below threshold"
    |   |   |       +-- File: {path}
    |   |   |       +-- Current: {file_coverage}%
    |   |   |       +-- Required: {per_file_threshold}%
    |   |   |
    |   |   +-- Check critical files:
    |   |       +-- Critical patterns: core/*, models/*, auth/*
    |   |       +-- IF critical_file_coverage < critical_threshold:
    |   |           +-- VIOLATION: "Critical file under-tested"
    |   |           +-- Severity: CRITICAL
    |   |
    |   +-- Check coverage trend:
    |       +-- IF historical data available:
    |       |   +-- Compare with previous coverage
    |       |   +-- IF coverage decreased:
    |       |       +-- VIOLATION: "Coverage regression detected"
    |       |       +-- Previous: {old_coverage}%
    |       |       +-- Current: {new_coverage}%
    |       |       +-- Delta: {delta}%
    |       |
    |       +-- ELSE: Store current coverage as baseline
    |
    +-- Analyze test quality:
    |   |
    |   +-- Check for test existence:
    |   |   +-- FOR each Python module:
    |   |       +-- Look for corresponding test file
    |   |       +-- Patterns: test_{module}.py, {module}*test.py
    |   |       +-- IF test file missing:
    |   |           +-- VIOLATION: "No test file for module"
    |   |           +-- Module: {module_path}
    |   |           +-- Expected: tests/test*{module}.py
    |   |
    |   +-- Check test patterns:
    |   |   +-- Scan for test anti-patterns:
    |   |   |   +-- Empty tests (pass only)
    |   |   |   +-- Disabled tests (@pytest.mark.skip without reason)
    |   |   |   +-- Tests without assertions
    |   |   |   +-- Overly broad try/except in tests
    |   |   |
    |   |   +-- IF anti-pattern found:
    |   |       +-- VIOLATION: "Test anti-pattern detected"
    |   |       +-- Pattern: {pattern_type}
    |   |       +-- Location: {file}:{line}
    |   |       +-- Severity: WARNING
    |   |
    |   +-- Check test organization:
    |       +-- Tests should be in tests/ directory
    |       +-- Test files should start with test_ or end with _test.py
    |       +-- IF organization violation:
    |           +-- VIOLATION: "Test organization issue"
    |           +-- Severity: INFO
    |
    +-- Generate uncovered code report:
    |   |
    |   +-- FOR each file with coverage gaps:
    |   |   +-- List uncovered lines
    |   |   +-- Categorize by type:
    |   |   |   +-- Uncovered branches
    |   |   |   +-- Uncovered statements
    |   |   |   +-- Uncovered functions
    |   |   |
    |   |   +-- Provide test suggestions:
    |   |       +-- "Add test for: {function_name}"
    |   |       +-- "Cover edge case: {scenario}"
    |   |       +-- "Test error path at line {line}"
    |   |
    |   +-- Generate coverage diff:
    |       +-- Show only new uncovered code
    |       +-- Highlight regression areas
    |
    +-- IF violations detected:
    |   |
    |   +-- Check enforcement level:
    |   |   |
    |   |   +-- STRICT:
    |   |   |   +-- BLOCK on overall threshold miss
    |   |   |   +-- BLOCK on new code threshold miss
    |   |   |   +-- BLOCK on critical file under-coverage
    |   |   |   +-- BLOCK on coverage regression
    |   |   |
    |   |   +-- BALANCED:
    |   |   |   +-- BLOCK on critical threshold miss
    |   |   |   +-- WARN on overall threshold miss
    |   |   |   +-- REQUIRE new code meets threshold
    |   |   |
    |   |   +-- PROTOTYPE:
    |   |       +-- LOG all violations
    |   |       +-- PASS unconditionally
    |   |
    |   +-- Generate actionable report:
    |   |   +-- Coverage Summary:
    |   |   |   +-- Overall: {current}% (required: {threshold}%)
    |   |   |   +-- New Code: {new_coverage}% (required: {new_threshold}%)
    |   |   |
    |   |   +-- Files Below Threshold:
    |   |   |   +-- {file}: {coverage}% (required: {threshold}%)
    |   |   |   +-- Uncovered lines: {line_ranges}
    |   |   |
    |   |   +-- Test Recommendations:
    |   |   |   +-- Add tests for: {uncovered_functions}
    |   |   |   +-- Cover branches: {uncovered_branches}
    |   |   |
    |   |   +-- Commands to Improve:
    |   |       +-- pytest {file} --cov={module} --cov-report=term-missing
    |   |       +-- Add test cases for lines: {line_numbers}
    |   |
    |   +-- IF auto-fix enabled:
    |   |   +-- Cannot auto-fix test coverage
    |   |   +-- Provide test template:
    |   |       +-- Generate skeleton test file
    |   |       +-- Include test stubs for uncovered functions
    |   |       +-- Mark with # TODO: Implement test
    |   |
    |   +-- IF blocking required:
    |       +-- BLOCK commit
    |       +-- Show coverage gap
    |       +-- Provide test templates
    |       +-- Exit with error
    |
    +-- Store coverage baseline:
    |   +-- Save coverage metrics to .sage/coverage-history.json
    |   +-- Track coverage over time
    |   +-- Enable trend analysis
    |
    +-- Generate validation report:
        +-- Coverage: {overall}%
        +-- Threshold: {threshold}%
        +-- Status: PASS/FAIL
        +-- New Code Coverage: {new_code}%
        +-- Files Tested: X/Y
        +-- Uncovered Lines: {count}
        |
        END

Rules:

- Minimum overall coverage: 80% (configurable)
- Minimum new code coverage: 90% (configurable)
- Critical files require 95% coverage
- No coverage regression allowed (STRICT mode)
- Test files required for all modules
- No empty tests or tests without assertions
- Coverage tool must be installed (pytest-cov or coverage.py)
- Tests must pass before coverage is assessed
- Auto-fix generates test templates only (manual implementation required)
- STRICT mode blocks on threshold violations
- BALANCED mode blocks on critical violations only
- PROTOTYPE mode logs only
- Coverage history tracked in .sage/coverage-history.json

Coverage Thresholds (Default):

- overall: 80%
- new_code: 90%
- per_file: 75%
- critical_files: 95%
- no_regression: true

Configuration (.coveragerc or pyproject.toml):

```toml
[tool.coverage.run]
source = ["."]
omit = ["tests/*", "*/migrations/*", "*/venv/*"]

[tool.coverage.report]
precision = 2
show_missing = true
skip_covered = false

[tool.coverage.sage]
minimum_coverage = 80
new_code_coverage = 90
fail_under = 80
critical_paths = ["core/*", "models/*", "auth/*"]
```

Test Anti-Patterns to Detect:

- Empty tests (only 'pass' statement)
- Tests without assertions
- @pytest.mark.skip without reason
- Overly broad try/except
- Tests that don't test anything
- Mocking everything (no real code tested)
- Tests with hardcoded success

Enforcement Actions:

- BLOCK: Prevent commit, coverage below threshold
- WARN: Log warning, allow to proceed
- LOG: Record for reference only
- TEMPLATE: Generate test skeleton (manual implementation required)


## import-enforcer


Algorithm:

  START: Import Validation
    |
    +-- Initialize
    |   +-- Get all Python files in changeset
    |   +-- Load import rules from rules/import-standards.md
    |   +-- Build project dependency graph
    |
    +-- FOR each Python file:
    |   |
    |   +-- Parse imports:
    |   |   +-- Standard library imports
    |   |   +-- Third-party imports
    |   |   +-- Local/project imports
    |   |   +-- Extract import statements and locations
    |   |
    |   +-- Check import placement:
    |   |   +-- REQUIRE: All imports at top of file
    |   |   +-- EXCEPT: After module docstring
    |   |   +-- EXCEPT: After from __future__ import
    |   |   +-- IF import in function/class body:
    |   |       +-- VIOLATION: "Import not at module level"
    |   |       +-- Location: {function/class} at line {lineno}
    |   |       +-- Severity: WARNING
    |   |       +-- Exception: Allowed for circular import resolution (with comment)
    |   |
    |   +-- Validate import style:
    |   |   |
    |   |   +-- Check for wildcard imports:
    |   |   |   +-- Pattern: from module import *
    |   |   |   +-- IF found:
    |   |   |       +-- VIOLATION: "Wildcard import detected"
    |   |   |       +-- Line: {lineno}
    |   |   |       +-- Severity: ERROR
    |   |   |       +-- Fix: Import specific names
    |   |   |
    |   |   +-- Check for relative imports:
    |   |   |   +-- Pattern: from . import, from .. import
    |   |   |   +-- IF found:
    |   |   |       +-- VIOLATION: "Relative import detected"
    |   |   |       +-- Line: {lineno}
    |   |   |       +-- Current: {import_statement}
    |   |   |       +-- Required: Absolute import path
    |   |   |       +-- Severity: ERROR
    |   |   |       +-- Auto-fix: Convert to absolute import
    |   |   |
    |   |   +-- Check for multiple imports per line:
    |   |   |   +-- Pattern: import os, sys
    |   |   |   +-- IF found:
    |   |   |       +-- VIOLATION: "Multiple imports on one line"
    |   |   |       +-- Line: {lineno}
    |   |   |       +-- Fix: Split into separate lines
    |   |   |       +-- Auto-fix: Reformat imports
    |   |   |
    |   |   +-- Check for unused imports:
    |   |       +-- Use AST analysis to find unused imports
    |   |       +-- IF import not used in file:
    |   |           +-- VIOLATION: "Unused import"
    |   |           +-- Import: {import_name}
    |   |           +-- Line: {lineno}
    |   |           +-- Severity: WARNING
    |   |           +-- Auto-fix: Remove unused import
    |   |
    |   +-- Validate import ordering (PEP 8):
    |   |   |
    |   |   +-- Expected order:
    |   |   |   1. from __future__ imports
    |   |   |   2. Standard library imports
    |   |   |   3. Third-party imports
    |   |   |   4. Local application imports
    |   |   |   (Blank line between each group)
    |   |   |
    |   |   +-- Check group ordering:
    |   |   |   +-- FOR each import:
    |   |   |       +-- Determine group (stdlib, third-party, local)
    |   |   |       +-- Track position
    |   |   |
    |   |   +-- Validate order:
    |   |   |   +-- IF groups out of order:
    |   |   |       +-- VIOLATION: "Import groups misordered"
    |   |   |       +-- Expected: {expected_order}
    |   |   |       +-- Found: {actual_order}
    |   |   |       +-- Auto-fix: Reorder imports
    |   |   |
    |   |   +-- Check alphabetical sorting within groups:
    |   |   |   +-- FOR each group:
    |   |   |       +-- Check imports sorted alphabetically
    |   |   |       +-- IF not sorted:
    |   |   |           +-- VIOLATION: "Imports not alphabetically sorted"
    |   |   |           +-- Group: {group_name}
    |   |   |           +-- Auto-fix: Sort imports
    |   |   |
    |   |   +-- Check blank lines between groups:
    |   |       +-- REQUIRE: Exactly one blank line between groups
    |   |       +-- IF missing or multiple:
    |   |           +-- VIOLATION: "Missing/extra blank lines"
    |   |           +-- Auto-fix: Normalize spacing
    |   |
    |   +-- Detect circular dependencies:
    |   |   |
    |   |   +-- Build import graph:
    |   |   |   +-- Node: Current file
    |   |   |   +-- Edges: Imported modules
    |   |   |
    |   |   +-- Run cycle detection (DFS):
    |   |   |   +-- Track visited nodes
    |   |   |   +-- Track current path
    |   |   |   +-- IF node in current path:
    |   |   |       +-- Circular dependency detected
    |   |   |
    |   |   +-- IF cycle found:
    |   |   |   +-- VIOLATION: "Circular import dependency"
    |   |   |   +-- Cycle: {module_a} → {module_b} → {module_a}
    |   |   |   +-- Severity: CRITICAL
    |   |   |   +-- Suggestions:
    |   |   |       +-- Move shared code to separate module
    |   |   |       +-- Use local imports in functions
    |   |   |       +-- Refactor to break dependency
    |   |   |
    |   |   +-- Store dependency graph:
    |   |       +-- Save to .sage/import-graph.json
    |   |       +-- Enable visualization
    |   |
    |   +-- Check import conventions:
    |   |   |
    |   |   +-- Standard library aliasing:
    |   |   |   +-- Check for non-standard aliases:
    |   |   |       +-- numpy → np (standard)
    |   |   |       +-- pandas → pd (standard)
    |   |   |       +-- matplotlib.pyplot → plt (standard)
    |   |   |       +-- IF non-standard alias:
    |   |   |           +-- VIOLATION: "Non-standard import alias"
    |   |   |           +-- Severity: INFO
    |   |   |
    |   |   +-- Check for discouraged imports:
    |   |   |   +-- Patterns:
    |   |   |       +-- from typing import Any (without justification)
    |   |   |       +-- import* (wildcard)
    |   |   |       +-- __import__ (dynamic imports)
    |   |   |   +-- IF found:
    |   |   |       +-- VIOLATION: "Discouraged import pattern"
    |   |   |       +-- Severity: WARNING
    |   |   |
    |   |   +-- Check for missing __init__.py:
    |   |       +-- If importing from package
    |   |       +-- Verify __init__.py exists
    |   |       +-- IF missing:
    |   |           +-- VIOLATION: "Package missing __init__.py"
    |   |           +-- Severity: ERROR
    |   |
    |   +-- Validate import type safety:
    |   |   |
    |   |   +-- Check TYPE_CHECKING imports:
    |   |   |   +-- from typing import TYPE_CHECKING
    |   |   |   +-- if TYPE_CHECKING: (import for type hints only)
    |   |   |   +-- Prevents circular imports in type annotations
    |   |   |   +-- IF type-only import at runtime:
    |   |   |       +-- VIOLATION: "Type-only import used at runtime"
    |   |   |       +-- Severity: ERROR
    |   |   |
    |   |   +-- Check forward references:
    |   |       +-- IF using string type annotations
    |   |       +-- RECOMMEND: from __future__ import annotations
    |   |
    |   +-- IF violations detected:
    |   |   |
    |   |   +-- Check enforcement level:
    |   |   |   |
    |   |   |   +-- STRICT:
    |   |   |   |   +-- BLOCK on ERROR severity
    |   |   |   |   +-- BLOCK on circular dependencies
    |   |   |   |   +-- Auto-fix ordering violations
    |   |   |   |   +-- Require manual fix for circular deps
    |   |   |   |
    |   |   |   +-- BALANCED:
    |   |   |   |   +-- Auto-fix ordering and style
    |   |   |   |   +-- WARN on circular dependencies
    |   |   |   |   +-- PASS with warnings
    |   |   |   |
    |   |   |   +-- PROTOTYPE:
    |   |   |       +-- LOG all violations
    |   |   |       +-- PASS unconditionally
    |   |   |
    |   |   +-- Generate violation report:
    |   |   |   +-- File: {path}
    |   |   |   +-- Violations: {count}
    |   |   |   +-- By severity:
    |   |   |       +-- CRITICAL: {circular_deps}
    |   |   |       +-- ERROR: {errors}
    |   |   |       +-- WARNING: {warnings}
    |   |   |       +-- INFO: {suggestions}
    |   |   |
    |   |   +-- IF auto-fix enabled:
    |   |   |   +-- Apply fixes:
    |   |   |   |   +-- Reorder imports (PEP 8)
    |   |   |   |   +-- Remove unused imports
    |   |   |   |   +-- Convert relative to absolute
    |   |   |   |   +-- Split multi-imports to separate lines
    |   |   |   |   +-- Normalize blank lines
    |   |   |   |
    |   |   |   +-- Verify syntax after fix:
    |   |   |   |   +-- IF syntax error:
    |   |   |   |       +-- ROLLBACK changes
    |   |   |   |       +-- BLOCK with error
    |   |   |   |
    |   |   |   +-- Log auto-fixes applied
    |   |   |
    |   |   +-- IF blocking required:
    |   |       +-- BLOCK operation
    |   |       +-- Show violation details
    |   |       +-- Provide fix guidance
    |   |
    |   +-- ELSE: Log as compliant
    |
    +-- Generate import graph visualization:
    |   +-- Export dependency graph
    |   +-- Generate mermaid diagram
    |   +-- Save to .sage/import-graph.md
    |
    +-- Generate validation report:
        +-- Files checked: X
        +-- Violations: Y
        +-- Auto-fixed: Z
        +-- Circular dependencies: N
        +-- Import graph saved: .sage/import-graph.json
        +-- Status: PASS/FAIL
        |
        END

Rules:

- All imports at module level (top of file)
- No wildcard imports (from x import *)
- Absolute imports only (no relative imports)
- One import per line
- PEP 8 import ordering: __future__, stdlib, third-party, local
- Alphabetical sorting within each group
- One blank line between import groups
- No circular dependencies
- Remove unused imports
- Standard aliases for common libraries (numpy→np, pandas→pd)
- TYPE_CHECKING for type-only imports
- __init__.py required for packages
- No __import__ or exec-based dynamic imports
- Auto-fix: Reordering, unused removal, relative→absolute
- Manual fix: Circular dependencies (suggest refactoring)

Import Order (PEP 8):

```python
"""Module docstring."""
from __future__ import annotations

import os
import sys

import numpy as np
import pandas as pd

from myproject.models import User
from myproject.utils import helper
```

Circular Dependency Resolution Strategies:

1. Move shared code to separate module
2. Use TYPE_CHECKING for type-only imports
3. Import inside function/method (local import)
4. Refactor to break dependency cycle
5. Use dependency injection

Enforcement Actions:

- BLOCK: Prevent operation on CRITICAL/ERROR violations
- WARN: Log warning, allow to proceed
- AUTO_FIX: Reorder, remove unused, convert to absolute
- MANUAL: Circular deps require developer intervention
- LOG: Record for reference only

Dependency Graph Format (.sage/import-graph.json):

```json
{
  "nodes": [
    {"id": "module_a", "type": "local"},
    {"id": "module_b", "type": "local"}
  ],
  "edges": [
    {"from": "module_a", "to": "module_b"}
  ],
  "cycles": [
    ["module_a", "module_b", "module_a"]
  ]
}
```

