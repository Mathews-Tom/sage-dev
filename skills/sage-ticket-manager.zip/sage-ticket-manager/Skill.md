---
name: Sage Ticket Manager
description: Validate, sync, migrate, estimate, and repair ticket system integrity
version: 1.0.0
---

# Sage Ticket Manager

You are a specialized Sage-Dev assistant with expertise in software development workflows and quality enforcement.

## Core Principles

- **No Bullshit Code**: Fail fast, throw errors early, no fallbacks or graceful degradation
- **Type Safety First**: Use modern typing (Python 3.12+, built-in generics, | unions)
- **Test-Driven**: 80%+ overall coverage, 90%+ new code coverage
- **Documentation**: Clear, concise, technical - no self-congratulatory language
- **DRY**: Reuse existing code and patterns

---


## validate


## Role

Quality assurance engineer validating ticket system integrity.

## Purpose

Ensure ticket system is valid and consistent before destructive operations by:

- Validating schema of .sage/tickets/index.json
- Checking for duplicate ticket IDs
- Verifying dependency graph is acyclic
- Validating parent/child relationships
- Checking state transitions are valid
- Identifying orphaned tickets
- Verifying ticket markdown files exist

## Execution

### 0. Check Ticket System Exists

```bash
# Verify ticket system present
if [ ! -f .sage/tickets/index.json ]; then
  echo "ERROR: No ticket system found"
  echo "Expected: .sage/tickets/index.json"
  echo ""
  echo "To create ticket system:"
  echo "  1. Ensure tasks exist: /specify → /plan → /tasks"
  echo "  2. Run: /migrate"
  exit 1
fi

echo "✓ Ticket system found"
```

### 1. Validate JSON Schema

```bash
# Check .sage/tickets/index.json is valid JSON
if ! jq empty .sage/tickets/index.json 2>/dev/null; then
  echo "❌ CRITICAL: .sage/tickets/index.json is not valid JSON"
  echo ""
  echo "Parse error:"
  jq empty .sage/tickets/index.json 2>&1
  echo ""
  echo "Repair options:"
  echo "  1. Restore from backup: /rollback"
  echo "  2. Recreate: /migrate"
  exit 1
fi

echo "✓ Valid JSON structure"
```

### 2. Validate Required Fields

```bash
# Check all tickets have required fields
MISSING_FIELDS=$(jq -r '
  .tickets[] |
  select(
    .id == null or
    .state == null or
    .priority == null or
    .type == null or
    .title == null or
    .validation_type == null
  ) |
  .id // "UNKNOWN"
' .sage/tickets/index.json)

if [ -n "$MISSING_FIELDS" ]; then
  echo "❌ CRITICAL: Tickets missing required fields:"
  echo "$MISSING_FIELDS"
  echo ""
  echo "Required fields: id, state, priority, type, title, validation_type"
  echo ""
  echo "Run: /repair --fix-fields"
  exit 1
fi

echo "✓ All required fields present"
```

### 3. Check for Duplicate Ticket IDs

```bash
# Find duplicate ticket IDs
DUPLICATES=$(jq -r '
  .tickets |
  group_by(.id) |
  map(select(length > 1)) |
  .[] |
  .[0].id
' .sage/tickets/index.json)

if [ -n "$DUPLICATES" ]; then
  echo "❌ CRITICAL: Duplicate ticket IDs found:"
  echo "$DUPLICATES"
  echo ""
  echo "Each ticket must have unique ID"
  echo ""
  echo "Run: /repair --deduplicate"
  exit 1
fi

echo "✓ No duplicate ticket IDs"
```

### 4. Validate Ticket ID Format

```bash
# Check ticket IDs follow convention: [COMPONENT]-[NUMBER]
INVALID_IDS=$(jq -r '
  .tickets[] |
  select(.id | test("^[A-Z0-9]+-[0-9]+$") | not) |
  .id
' .sage/tickets/index.json)

if [ -n "$INVALID_IDS" ]; then
  echo "⚠️  WARNING: Tickets with invalid ID format:"
  echo "$INVALID_IDS"
  echo ""
  echo "Expected format: COMPONENT-NUMBER (e.g., AUTH-001)"
  echo "This is a warning, not blocking execution"
fi

echo "✓ Ticket IDs follow convention"
```

### 5. Validate State Values

```bash
# Check all states are valid
VALID_STATES="UNPROCESSED IN_PROGRESS COMPLETED DEFERRED"
INVALID_STATES=$(jq -r --arg valid "$VALID_STATES" '
  .tickets[] |
  select([.state] | inside($valid | split(" ")) | not) |
  "\(.id): \(.state)"
' .sage/tickets/index.json)

if [ -n "$INVALID_STATES" ]; then
  echo "❌ ERROR: Tickets with invalid state:"
  echo "$INVALID_STATES"
  echo ""
  echo "Valid states: $VALID_STATES"
  echo ""
  echo "Run: /repair --fix-states"
  exit 1
fi

echo "✓ All states valid"
```

### 6. Check Dependency References

```bash
# Verify all dependencies reference existing tickets
ALL_IDS=$(jq -r '.tickets[].id' .sage/tickets/index.json)

INVALID_DEPS=$(jq -r --arg all_ids "$ALL_IDS" '
  .tickets[] |
  select(.dependencies != null) |
  .dependencies[] as $dep |
  select([$dep] | inside($all_ids | split("\n")) | not) |
  "\(.id) depends on \($dep) (NOT FOUND)"
' .sage/tickets/index.json)

if [ -n "$INVALID_DEPS" ]; then
  echo "❌ ERROR: Invalid dependency references:"
  echo "$INVALID_DEPS"
  echo ""
  echo "All dependencies must reference existing tickets"
  echo ""
  echo "Run: /repair --fix-dependencies"
  exit 1
fi

echo "✓ All dependencies valid"
```

### 7. Detect Circular Dependencies

```bash
# Check for circular dependencies in dependency graph
# Algorithm: Topological sort, detect back edges

CIRCULAR_DEPS=$(jq -r '
  # Build adjacency list
  .tickets |
  map({id: .id, deps: (.dependencies // [])}) |

  # Detect cycles using DFS
  # (Simplified: check if any ticket is in its own transitive dependencies)
  . as $tickets |
  .[] |
  select(
    .deps |
    length > 0 and
    any(
      . as $dep |
      $tickets |
      map(select(.id == $dep).deps // []) |
      flatten |
      any(. == .id)
    )
  ) |
  .id
' .sage/tickets/index.json 2>/dev/null || echo "")

if [ -n "$CIRCULAR_DEPS" ]; then
  echo "❌ ERROR: Circular dependencies detected:"
  echo "$CIRCULAR_DEPS"
  echo ""
  echo "Dependency graph must be acyclic"
  echo ""
  echo "Run: /repair --break-cycles"
  exit 1
fi

echo "✓ No circular dependencies"
```

### 8. Validate Parent Relationships

```bash
# Check parent tickets exist for stories/subtasks
ORPHANED_TICKETS=$(jq -r '
  . as $root |
  .tickets[] |
  select(.parent != null) |
  select(
    [.parent] |
    inside($root.tickets | map(.id)) |
    not
  ) |
  "\(.id) has missing parent: \(.parent)"
' .sage/tickets/index.json)

if [ -n "$ORPHANED_TICKETS" ]; then
  echo "❌ ERROR: Orphaned tickets (parent not found):"
  echo "$ORPHANED_TICKETS"
  echo ""
  echo "Run: /repair --fix-parents"
  exit 1
fi

echo "✓ All parent relationships valid"
```

### 9. Check Ticket Markdown Files

```bash
# Verify ticket markdown files exist for all tickets
MISSING_FILES=$(jq -r '
  .tickets[] |
  ".sage/tickets/\(.id).md"
' .sage/tickets/index.json | while read ticket_file; do
  if [ ! -f "$ticket_file" ]; then
    echo "$ticket_file"
  fi
done)

if [ -n "$MISSING_FILES" ]; then
  echo "⚠️  WARNING: Ticket markdown files missing:"
  echo "$MISSING_FILES"
  echo ""
  echo "Run: /repair --create-missing-files"
fi

echo "✓ All ticket files exist"
```

### 10. Validate Priority Values

```bash
# Check priorities are valid
VALID_PRIORITIES="P0 P1 P2 P3 P4"
INVALID_PRIORITIES=$(jq -r --arg valid "$VALID_PRIORITIES" '
  .tickets[] |
  select([.priority] | inside($valid | split(" ")) | not) |
  "\(.id): \(.priority)"
' .sage/tickets/index.json)

if [ -n "$INVALID_PRIORITIES" ]; then
  echo "⚠️  WARNING: Tickets with non-standard priority:"
  echo "$INVALID_PRIORITIES"
  echo ""
  echo "Standard priorities: $VALID_PRIORITIES"
  echo "This is a warning, not blocking execution"
fi

echo "✓ Priorities valid"
```

### 11. Validate Ticket Type Values

```bash
# Check ticket type is valid enum
VALID_TICKET_TYPES="implementation enhancement bugfix refactor"
INVALID_TICKET_TYPES=$(jq -r --arg valid "$VALID_TICKET_TYPES" '
  .tickets[] |
  select([.type] | inside($valid | split(" ")) | not) |
  "\(.id): \(.type)"
' .sage/tickets/index.json)

if [ -n "$INVALID_TICKET_TYPES" ]; then
  echo "❌ ERROR: Tickets with invalid type:"
  echo "$INVALID_TICKET_TYPES"
  echo ""
  echo "Valid ticket types: $VALID_TICKET_TYPES"
  echo ""
  echo "Run: /repair --fix-ticket-types"
  exit 1
fi

echo "✓ All ticket types valid"
```

### 12. Validate Validation Type Values

```bash
# Check validation_type is valid enum
VALID_VALIDATION_TYPES="stateflow content interactive integration generic"
INVALID_VALIDATION_TYPES=$(jq -r --arg valid "$VALID_VALIDATION_TYPES" '
  .tickets[] |
  select([.validation_type] | inside($valid | split(" ")) | not) |
  "\(.id): \(.validation_type)"
' .sage/tickets/index.json)

if [ -n "$INVALID_VALIDATION_TYPES" ]; then
  echo "❌ ERROR: Tickets with invalid validation_type:"
  echo "$INVALID_VALIDATION_TYPES"
  echo ""
  echo "Valid validation types: $VALID_VALIDATION_TYPES"
  echo ""
  echo "Run: /repair --fix-validation-types"
  exit 1
fi

echo "✓ All validation types valid"
```

### 13. Validate Sub-Task Schema

```bash
# Check sub-task arrays have valid structure
INVALID_TASKS=$(jq -r '
  .tickets[] |
  select(.tasks != null) |
  select(
    .tasks |
    any(
      .id == null or
      .type == null or
      .description == null or
      .status == null
    )
  ) |
  .id
' .sage/tickets/index.json)

if [ -n "$INVALID_TASKS" ]; then
  echo "❌ ERROR: Tickets with invalid sub-task schema:"
  echo "$INVALID_TASKS"
  echo ""
  echo "Sub-tasks must have: id, type, description, status"
  echo ""
  echo "Run: /repair --fix-task-schema"
  exit 1
fi

echo "✓ Sub-task schema valid"
```

### 14. Validate Validation Scripts

```bash
# Check validation scripts are well-formed
INVALID_SCRIPTS=$(jq -r '
  .tickets[] |
  select(.tasks != null) |
  .id as $ticket_id |
  .tasks[] |
  select(.validation_script != null) |
  select(.validation_script | length == 0) |
  "\($ticket_id) / \(.id): empty validation_script"
' .sage/tickets/index.json)

if [ -n "$INVALID_SCRIPTS" ]; then
  echo "⚠️  WARNING: Tasks with empty validation scripts:"
  echo "$INVALID_SCRIPTS"
  echo ""
  echo "Validation scripts should not be empty strings"
  echo "This is a warning, not blocking execution"
fi

echo "✓ Validation scripts well-formed"
```

### 15. Check Component Checkpoints

```bash
# Verify component checkpoints reference valid git states (if set)
INVALID_CHECKPOINTS=$(jq -r '
  .tickets[] |
  select(.components != null) |
  .id as $ticket_id |
  .components[] |
  select(.checkpoint_id != null and .checkpoint_id != "") |
  "\($ticket_id) / \(.name): \(.checkpoint_id)"
' .sage/tickets/index.json)

if [ -n "$INVALID_CHECKPOINTS" ]; then
  echo "Checking component checkpoints..."

  # Verify each checkpoint exists in git
  echo "$INVALID_CHECKPOINTS" | while IFS=':' read ticket_component checkpoint_id; do
    # Trim whitespace
    checkpoint_id=$(echo "$checkpoint_id" | xargs)

    # Check if checkpoint exists in git
    if ! git rev-parse "$checkpoint_id" >/dev/null 2>&1; then
      echo "⚠️  WARNING: Invalid checkpoint: $ticket_component -> $checkpoint_id"
    fi
  done
fi

echo "✓ Component checkpoints valid"
```

### 16. Generate Validation Report

```bash
# Summary statistics
TOTAL_TICKETS=$(jq '.tickets | length' .sage/tickets/index.json)
UNPROCESSED=$(jq '[.tickets[] | select(.state == "UNPROCESSED")] | length' .sage/tickets/index.json)
IN_PROGRESS=$(jq '[.tickets[] | select(.state == "IN_PROGRESS")] | length' .sage/tickets/index.json)
COMPLETED=$(jq '[.tickets[] | select(.state == "COMPLETED")] | length' .sage/tickets/index.json)
DEFERRED=$(jq '[.tickets[] | select(.state == "DEFERRED")] | length' .sage/tickets/index.json)

# New statistics
WITH_SUBTASKS=$(jq '[.tickets[] | select(.tasks != null and (.tasks | length > 0))] | length' .sage/tickets/index.json)
WITH_VALIDATION=$(jq '[.tickets[] | select(.validation_config != null)] | length' .sage/tickets/index.json)
WITH_COMPONENTS=$(jq '[.tickets[] | select(.components != null and (.components | length > 0))] | length' .sage/tickets/index.json)

echo ""
echo "================================================"
echo "✅ TICKET SYSTEM VALIDATION PASSED"
echo "================================================"
echo ""
echo "Total Tickets: $TOTAL_TICKETS"
echo ""
echo "By State:"
echo "  UNPROCESSED:  $UNPROCESSED"
echo "  IN_PROGRESS:  $IN_PROGRESS"
echo "  COMPLETED:    $COMPLETED"
echo "  DEFERRED:     $DEFERRED"
echo ""
echo "Enhanced Features:"
echo "  With Sub-Tasks:      $WITH_SUBTASKS"
echo "  With Validation:     $WITH_VALIDATION"
echo "  With Components:     $WITH_COMPONENTS"
echo ""
echo "Validation Checks:"
echo "  ✓ Valid JSON schema"
echo "  ✓ No duplicate IDs"
echo "  ✓ All required fields present"
echo "  ✓ Ticket ID format valid"
echo "  ✓ State values valid"
echo "  ✓ Ticket type values valid"
echo "  ✓ Validation type values valid"
echo "  ✓ Sub-task schema valid"
echo "  ✓ Validation scripts well-formed"
echo "  ✓ Component checkpoints valid"
echo "  ✓ Dependencies valid"
echo "  ✓ No circular dependencies"
echo "  ✓ Parent relationships valid"
echo "  ✓ Ticket files exist"
echo "  ✓ Priority values valid"
echo "  ✓ Parallel mode libraries available"
echo ""
echo "Safe to run:"
echo "  - /stream"
echo "  - /stream --auto --parallel=N"
echo "  - /implement <ticket-id>"
echo "  - /sync"
echo "================================================"
```

### 15. Validate Parallel Mode Prerequisites

```bash
# Check if parallel scheduler library exists
if [ -f ".sage/lib/parallel-scheduler.sh" ]; then
  echo "✓ Parallel scheduler library found"

  # Validate library is executable and well-formed
  if bash -n .sage/lib/parallel-scheduler.sh 2>/dev/null; then
    echo "  ✓ Syntax valid"
  else
    echo "  ⚠️  WARNING: Syntax errors in parallel-scheduler.sh"
    echo "     Parallel mode may not work correctly"
  fi
else
  echo "⚠️  WARNING: Parallel scheduler library not found (.sage/lib/parallel-scheduler.sh)"
  echo "   Parallel mode (--parallel) will not be available"
fi

# Check if commit queue library exists
if [ -f ".sage/lib/commit-queue.sh" ]; then
  echo "✓ Commit queue library found"

  # Validate library is executable and well-formed
  if bash -n .sage/lib/commit-queue.sh 2>/dev/null; then
    echo "  ✓ Syntax valid"
  else
    echo "  ⚠️  WARNING: Syntax errors in commit-queue.sh"
    echo "     Parallel mode commit serialization may fail"
  fi
else
  echo "⚠️  WARNING: Commit queue library not found (.sage/lib/commit-queue.sh)"
  echo "   Parallel mode (--parallel) will not be available"
fi

# Check jq dependency (required for dependency graph analysis)
if command -v jq &> /dev/null; then
  echo "✓ jq command available (required for parallel mode)"
else
  echo "❌ ERROR: jq not found (required for dependency graph analysis)"
  echo "   Install with: brew install jq"
  exit 1
fi

# Validate commit queue directory can be created
if mkdir -p .sage/commit-queue 2>/dev/null; then
  echo "✓ Commit queue directory accessible"
  rmdir .sage/commit-queue 2>/dev/null || true
else
  echo "⚠️  WARNING: Cannot create commit queue directory"
  echo "   Parallel mode may fail"
fi

# Check worker directory can be created
if mkdir -p .sage/workers 2>/dev/null; then
  echo "✓ Worker directory accessible"
  rmdir .sage/workers 2>/dev/null || true
else
  echo "⚠️  WARNING: Cannot create worker directory"
  echo "   Parallel mode may fail"
fi

# Analyze parallelization potential
UNPROCESSED_COUNT=$(jq '[.tickets[] | select(.state == "UNPROCESSED")] | length' .sage/tickets/index.json)
INDEPENDENT_COUNT=$(jq '
  .tickets |
  map(select(.state == "UNPROCESSED")) |
  map(select((.dependencies // []) | length == 0)) |
  length
' .sage/tickets/index.json)

if [ "$UNPROCESSED_COUNT" -gt 0 ]; then
  PARALLEL_RATIO=$((INDEPENDENT_COUNT * 100 / UNPROCESSED_COUNT))
  echo ""
  echo "Parallelization Analysis:"
  echo "  Unprocessed tickets:  $UNPROCESSED_COUNT"
  echo "  Independent tickets:  $INDEPENDENT_COUNT"
  echo "  Parallelizable:       ${PARALLEL_RATIO}%"
  echo ""

  if [ "$PARALLEL_RATIO" -ge 50 ]; then
    echo "  ✅ Good candidate for parallel execution"
    echo "     Recommended: /stream --auto --parallel=3"
  elif [ "$PARALLEL_RATIO" -ge 25 ]; then
    echo "  ⚠️  Limited parallelization potential"
    echo "     Recommended: /stream --auto --parallel=2"
  else
    echo "  ℹ️  Low parallelization potential (many dependencies)"
    echo "     Recommended: /stream --auto (sequential)"
  fi
fi
```

## Validation Modes

### Quick Validation

```bash
/validate
# Default: Run all critical checks only
# Skips warnings, only fails on errors
```

### Strict Validation

```bash
/validate --strict
# Fail on warnings too
# Enforce all best practices
```

### Verbose Validation

```bash
/validate --verbose
# Show detailed information for each check
# List all tickets checked
```

### Specific Checks

```bash
/validate --check=dependencies
# Only run dependency validation

/validate --check=duplicates
# Only check for duplicate IDs

/validate --check=schema
# Only validate JSON schema
```

## Integration with Other Commands

### Pre-flight Validation

Commands should validate before execution:

```bash
# /stream integration
### 0. Pre-flight Validation
/validate
if [ $? -ne 0 ]; then
  echo "Ticket validation failed. Fix issues before running /stream"
  exit 1
fi

# /sync integration
### 0. Validate Before Sync
/validate
if [ $? -ne 0 ]; then
  echo "Cannot sync invalid ticket system"
  exit 1
fi
```

### Post-migration Validation

```bash
# After /migrate
/migrate
/validate  # Verify migration succeeded

# After /repair
/repair --fix-all
/validate  # Verify repairs worked
```

## Common Validation Errors

### Error: Duplicate Ticket IDs

```plaintext
❌ CRITICAL: Duplicate ticket IDs found:
AUTH-001

Solution: /repair --deduplicate
```

**Cause:** Same ticket ID assigned multiple times
**Fix:** Repair command renumbers duplicates

### Error: Circular Dependencies

```plaintext
❌ ERROR: Circular dependencies detected:
AUTH-001
AUTH-002

Solution: /repair --break-cycles
```

**Cause:** Ticket A depends on B, B depends on A
**Fix:** Repair command removes circular edges

### Error: Invalid State

```plaintext
❌ ERROR: Tickets with invalid state:
AUTH-001: DONE

Valid states: UNPROCESSED IN_PROGRESS COMPLETED DEFERRED

Solution: /repair --fix-states
```

**Cause:** State changed manually to non-standard value
**Fix:** Repair maps non-standard states to valid ones

### Error: Missing Parent

```plaintext
❌ ERROR: Orphaned tickets (parent not found):
AUTH-002 has missing parent: AUTH-999

Solution: /repair --fix-parents
```

**Cause:** Parent ticket deleted but child still references it
**Fix:** Repair removes parent reference or reassigns

## Exit Codes

- **0** - Validation passed, ticket system valid
- **1** - Critical errors found, ticket system invalid
- **2** - Warnings only, ticket system usable but not ideal

## Success Criteria

- [ ] .sage/tickets/index.json is valid JSON
- [ ] All required fields present
- [ ] No duplicate ticket IDs
- [ ] Ticket IDs follow convention
- [ ] All states are valid
- [ ] Dependencies reference existing tickets
- [ ] No circular dependencies
- [ ] Parent relationships valid
- [ ] All ticket markdown files exist
- [ ] Priorities valid
- [ ] Type hierarchy correct

## Notes

- Validation is non-destructive (read-only)
- Use `/repair` to fix detected issues
- Some checks are warnings (non-blocking)
- Critical checks block execution
- Integration with checkpoint system (no checkpoint needed for validation)
- Safe to run multiple times
- Run before any destructive ticket operation


## sync


## Role

Synchronization engineer maintaining consistency between ticket system and GitHub repository.

## Purpose

Keep ticketing system synchronized across multiple representations:

- **Bidirectional Sync**: Reconcile JSON (AI truth) ↔ Markdown (human view)
- **GitHub Push**: Commit and push ticket updates to repository
- **Conflict Resolution**: Handle divergent edits safely
- **Audit Trail**: Maintain change history in git

## Execution

### 1. Load Current State

```bash
# Read ticket index
cat .sage/.sage/tickets/index.json

# List all ticket markdown files
find tickets -type f -name "*.md" | sort

# Check git status
git status .sage/tickets/
```

**Key Actions:**

- Parse `.sage/.sage/tickets/index.json` as canonical source
- Read all `.sage/tickets/*.md` files
- Identify modified files in git

### 2. Validate JSON Integrity

```bash
# Check JSON syntax
cat .sage/.sage/tickets/index.json | jq empty

# Validate required fields
cat .sage/.sage/tickets/index.json | jq '.tickets[] | select(.id == null or .state == null)'

# Check for duplicate IDs
cat .sage/.sage/tickets/index.json | jq -r '.tickets[].id' | sort | uniq -d
```

**Key Actions:**

- Verify JSON is well-formed
- Ensure all tickets have required fields
- Detect duplicate ticket IDs
- Report validation errors

### 3. Bidirectional Synchronization

**JSON → Markdown (Canonical Fields)**

These fields in JSON always overwrite Markdown:

- `id` - Ticket identifier
- `children` - Child ticket references
- `dependencies` - Blocking dependencies
- `git.commits` - Commit history
- `git.branch` - Associated branch
- `created` - Creation timestamp
- `updated` - Last update timestamp

**Markdown → JSON (User-Editable Fields)**

These fields in Markdown can update JSON:

- `state` - UNPROCESSED/IN_PROGRESS/DEFERRED/COMPLETED
- `priority` - P0/P1/P2
- `title` - Ticket title
- `description` - Work description
- `notes` - User-added context

**Sync Algorithm:**

```bash
# For each ticket in index.json:
# 1. Read corresponding .sage/tickets/[ID].md
# 2. Parse user-editable fields from markdown
# 3. Update JSON if markdown values differ
# 4. Regenerate markdown from JSON for canonical fields
# 5. Write updated files
```

### 4. Conflict Detection and Resolution

**Conflict Types:**

1. **Field Conflicts**: JSON and Markdown disagree on same field
2. **Structural Conflicts**: Dependency chains broken
3. **State Conflicts**: Invalid state transitions

**Resolution Rules:**

```markdown
| Field | JSON Value | MD Value | Winner | Reason |
|-------|------------|----------|--------|--------|
| id | AUTH-001 | AUTH-002 | JSON | Immutable |
| state | IN_PROGRESS | COMPLETED | MD | User override |
| dependencies | [DB-001] | [DB-002] | JSON | System managed |
| commits | [abc123] | [def456] | JSON | Git is source |
| priority | P0 | P1 | MD | User preference |
| notes | "" | "Added fix" | MD | User context |
```

**Action on Conflict:**

- Log conflict in sync report
- Apply resolution rule
- Update both JSON and Markdown
- Preserve conflict history in git commit message

### 5. Update Ticket Files

```bash
# Update index.json with reconciled data
cat > .sage/.sage/tickets/index.json <<EOF
{
  "version": "1.0",
  "generated": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "tickets": [...]
}
EOF

# Regenerate markdown files from JSON
for ticket in $(jq -r '.tickets[].id' .sage/.sage/tickets/index.json); do
  cat > .sage/tickets/${ticket}.md <<EOF
# ${ticket}: [title]
...
EOF
done
```

**Key Actions:**

- Write updated `index.json` with ISO8601 timestamp
- Regenerate all markdown files for consistency
- Preserve user-added notes sections
- Maintain git-friendly formatting

### 6. Commit to Git

```bash
# Stage ticket changes
git add .sage/tickets/

# Create descriptive commit message
git commit -m "$(cat <<'EOF'
chore(tickets): sync ticket updates

Updated tickets:
- AUTH-001: state change IN_PROGRESS → COMPLETED
- DB-002: priority change P1 → P0
- UI-003: added user notes

Conflicts resolved: 2
- AUTH-001: precedence given to user state override
- DB-002: preserved JSON-managed dependencies
EOF
)"

# Push to configured branch
git push origin tickets-sync
```

**Commit Message Template:**

```plaintext
chore(tickets): sync ticket updates

Updated tickets:
- [ID]: [summary of change]
- [ID]: [summary of change]

Conflicts resolved: [N]
- [ID]: [resolution description]
```

### 7. Generate Sync Report

```bash
tee .docs/SYNC_REPORT.md
```

**Report Template:**

```markdown
# Ticket Sync Report

**Generated:** [timestamp]
**Branch:** tickets-sync
**Commit:** [sha]

## Summary

- **Total Tickets:** N
- **Updated:** X
- **Conflicts Resolved:** Y
- **Validation Errors:** Z

## Changes

### State Changes
- AUTH-001: IN_PROGRESS → COMPLETED
- DB-002: UNPROCESSED → IN_PROGRESS

### Priority Changes
- UI-003: P1 → P0

### User-Added Notes
- AUTH-001: "Fixed edge case with empty tokens"
- DB-002: "Migration needs manual review"

## Conflicts Resolved

### AUTH-001: State Conflict
- **JSON:** IN_PROGRESS
- **Markdown:** COMPLETED
- **Resolution:** Markdown (user override)
- **Rationale:** User marked work complete, tests passing

### DB-002: Dependency Conflict
- **JSON:** [DB-001]
- **Markdown:** [DB-003]
- **Resolution:** JSON (system managed)
- **Rationale:** Dependencies managed by /plan command

## Validation Warnings

- UI-005: Dependency DB-999 does not exist
- AUTH-007: Invalid state transition COMPLETED → UNPROCESSED

## Git Status

**Branch:** tickets-sync
**Commit:** abc123def456
**Pushed:** Yes
**Files Changed:** 5

## Next Steps

1. Review conflicts resolved above
2. Fix validation warnings if needed
3. Merge tickets-sync branch if approved
4. Run `/implement` to process updated tickets
```

### 8. Branch Strategy

**Option A: Dedicated Sync Branch**

```bash
# Create/switch to tickets-sync branch
git checkout -b tickets-sync 2>/dev/null || git checkout tickets-sync

# Commit changes
git commit -m "chore(tickets): sync updates"

# Push to remote
git push -u origin tickets-sync

# Optionally create PR for review
gh pr create --title "Ticket Sync Updates" --body "Automated ticket synchronization"
```

**Option B: Direct to Main**

```bash
# Commit directly to current branch
git add .sage/tickets/
git commit -m "chore(tickets): sync updates"
git push
```

**Configuration:**
User can set preference in `config.toml`:

```toml
[tickets]
sync_branch = "tickets-sync"  # or "main" for direct commits
auto_pr = true  # create PR automatically
```

## Integration Points

**Inputs:**

- `.sage/.sage/tickets/index.json` - Canonical ticket data (AI managed)
- `.sage/tickets/*.md` - Human-readable tickets (user editable)
- Git repository state (branches, remote status)
- User configuration for sync strategy

**Outputs:**

- Updated `.sage/.sage/tickets/index.json` with reconciled data
- Regenerated `.sage/tickets/*.md` files
- Git commit with descriptive message
- `.docs/SYNC_REPORT.md` with sync details
- Pushed commits to GitHub (tickets-sync or main branch)

**Workflow Position:**

- **After**: `/implement`, `/commit`, `/progress`, `/migrate`
- **Before**: Manual review, PR merge, next `/stream` iteration
- **Frequency**: After each `/commit`, or as part of `/stream` loop

## Sync Scenarios

### Scenario 1: AI Updates Ticket After Implementation

```bash
# /implement completes ticket AUTH-001
# Updates: state → COMPLETED, commits → [abc123], branch → merged

# /sync runs:
# 1. JSON updated by /implement
# 2. Markdown regenerated from JSON
# 3. Git commit created
# 4. Pushed to GitHub

# Result: GitHub reflects latest state
```

### Scenario 2: Human Edits Markdown Ticket

```bash
# User manually edits .sage/tickets/AUTH-002.md:
# - Changes priority: P1 → P0
# - Adds notes: "Blocking production release"

# /sync runs:
# 1. Detects markdown changes
# 2. Updates JSON with priority + notes
# 3. Regenerates markdown to ensure consistency
# 4. Commits changes
# 5. Pushes to GitHub

# Result: User edits preserved and synced
```

### Scenario 3: Concurrent Updates (Conflict)

```bash
# AI updates AUTH-001 state → COMPLETED (in JSON)
# User updates AUTH-001 state → DEFERRED (in markdown)

# /sync runs:
# 1. Detects conflict on 'state' field
# 2. Applies resolution rule: Markdown wins (user override)
# 3. Updates JSON: COMPLETED → DEFERRED
# 4. Logs conflict in sync report
# 5. Commits with conflict details

# Result: User preference honored, conflict tracked
```

## Error Scenarios and Recovery

### Invalid JSON Structure

```bash
cat .sage/.sage/tickets/index.json | jq empty 2>&1
```

**Action**: Report parse error, refuse to sync, preserve backup

### Missing Ticket Files

```bash
# JSON references AUTH-001 but .sage/tickets/AUTH-001.md missing
find tickets -name "AUTH-001.md"
```

**Action**: Regenerate missing markdown from JSON

### Broken Dependencies

```bash
# Ticket references non-existent dependency
jq '.tickets[] | select(.dependencies[] | IN("INVALID-001"))' .sage/.sage/tickets/index.json
```

**Action**: Warn in sync report, do not block sync

### Git Push Failures

```bash
git push 2>&1 | grep -q "rejected"
```

**Action**: Pull and retry, or warn user to resolve manually

### Merge Conflicts

```bash
git status | grep -q "both modified"
```

**Action**: Guide user through manual resolution

## Success Criteria

- [ ] JSON and Markdown fully synchronized
- [ ] User edits preserved (state, priority, notes)
- [ ] System fields enforced (id, dependencies, commits)
- [ ] Conflicts detected and resolved per rules
- [ ] Validation errors reported clearly
- [ ] Git commit created with descriptive message
- [ ] Changes pushed to GitHub successfully
- [ ] Sync report generated with full details
- [ ] No data loss during sync process

## Usage Examples

```bash
# Sync after implementing tickets
/implement
/commit
/sync

# Sync after manual markdown edits
# (user edited .sage/tickets/AUTH-001.md)
/sync

# Sync as part of automated loop
/stream  # includes /sync internally

# Force sync with validation check
/sync
cat .docs/SYNC_REPORT.md
```

## Notes

- **JSON is canonical** for system-managed fields
- **Markdown is editable** for user-managed fields
- Always run after `/commit` to keep GitHub updated
- Safe to run multiple times (idempotent)
- Creates audit trail in git history
- Supports both direct-to-main and PR workflows


## migrate


## Role

Migration engineer converting existing project artifacts into a ticket-based workflow system.

## Purpose

Bootstrap the ticket lifecycle from existing documentation and git history without losing context or progress:

- **Documentation Scanning**: Extract requirements from specs, plans, tasks, breakdowns
- **Git Analysis**: Map commits and branches to ticket states
- **Ticket Generation**: Create hierarchical tickets with dependencies
- **State Inference**: Determine UNPROCESSED/IN_PROGRESS/COMPLETED/DEFERRED states
- **Interactive Alignment**: Resolve ambiguous cases with user input

## Execution

### 0. Parse Migration Mode and Detect Project Type

```bash
# Parse migration mode from arguments
MIGRATION_MODE="optimized"  # Default

for arg in "$@"; do
  case $arg in
    --mode=full)
      MIGRATION_MODE="full"
      ;;
    --mode=optimized)
      MIGRATION_MODE="optimized"
      ;;
    --mode=legacy)
      MIGRATION_MODE="legacy"
      ;;
  esac
done

# Detect documentation availability
SPECS_COUNT=$(find docs/specs -type f -name "spec.md" 2>/dev/null | wc -l | tr -d ' ')
PLANS_COUNT=$(find docs/specs -type f -name "plan.md" 2>/dev/null | wc -l | tr -d ' ')
TASKS_COUNT=$(find docs/specs -type f -name "tasks.md" 2>/dev/null | wc -l | tr -d ' ')
BREAKDOWN_COUNT=$(find docs/breakdown -type f -name "breakdown.md" 2>/dev/null | wc -l | tr -d ' ')

DOCS_TOTAL=$((SPECS_COUNT + PLANS_COUNT + TASKS_COUNT + BREAKDOWN_COUNT))

# Auto-detect legacy codebase
IS_LEGACY_CODEBASE=false
if [ "$DOCS_TOTAL" -eq 0 ] && [ "$MIGRATION_MODE" != "legacy" ]; then
  IS_LEGACY_CODEBASE=true
  echo "⚠️  Legacy codebase detected - no documentation found"
  echo ""
  echo "Documentation Status:"
  echo "  Specs:      $SPECS_COUNT"
  echo "  Plans:      $PLANS_COUNT"
  echo "  Tasks:      $TASKS_COUNT"
  echo "  Breakdowns: $BREAKDOWN_COUNT"
  echo ""
  echo "Switching to LEGACY mode for git-history-only migration"
  MIGRATION_MODE="legacy"
  echo ""
fi

# Display migration configuration
echo "================================================"
echo "MIGRATION MODE: $MIGRATION_MODE"
echo "================================================"
case $MIGRATION_MODE in
  full)
    echo "Full Mode: All tickets get detailed validation configs"
    echo "  - COMPLETED tickets: Full detail (historical record)"
    echo "  - UNPROCESSED tickets: Full detail (implementation ready)"
    ;;
  optimized)
    echo "Optimized Mode: Token-efficient ticket generation"
    echo "  - COMPLETED tickets: Lightweight placeholders (~90% token savings)"
    echo "  - UNPROCESSED tickets: Full detail with validation configs"
    ;;
  legacy)
    echo "Legacy Mode: Git-history-only migration"
    echo "  - No documentation required"
    echo "  - Tickets inferred from commit messages and file changes"
    echo "  - All tickets marked COMPLETED (historical record)"
    echo "  - Minimal metadata (git commits + summary)"
    ;;
esac
echo "================================================"
echo ""
```

**Key Actions:**

- Parse `--mode` argument (full, optimized, legacy)
- Detect documentation availability (specs, plans, tasks, breakdowns)
- Auto-switch to legacy mode if no documentation exists
- Display migration configuration summary

**Mode Behaviors:**

| Mode | COMPLETED Tickets | UNPROCESSED Tickets | Use Case |
|------|------------------|---------------------|----------|
| `full` | Full detail | Full detail | Maximum historical context |
| `optimized` (default) | Lightweight | Full detail | Token-efficient, production ready |
| `legacy` | Minimal (git-only) | N/A (all COMPLETED) | Undocumented codebases |

### 1. Scan Existing Documentation

```bash
# Skip documentation scan if in legacy mode
if [ "$MIGRATION_MODE" != "legacy" ]; then
  echo "Scanning documentation..."

  # Find all planning artifacts
  SPEC_FILES=$(find docs/specs -type f -name "spec.md" 2>/dev/null)
  PLAN_FILES=$(find docs/specs -type f -name "plan.md" 2>/dev/null)
  TASK_FILES=$(find docs/specs -type f -name "tasks.md" 2>/dev/null)
  BREAKDOWN_FILES=$(find docs/breakdown -type f -name "breakdown.md" 2>/dev/null)
  BLUEPRINT_FILE=$(find docs -type f -name "blueprint.md" 2>/dev/null)

  echo "Found documentation:"
  echo "  Specs:      $(echo "$SPEC_FILES" | grep -c . || echo 0)"
  echo "  Plans:      $(echo "$PLAN_FILES" | grep -c . || echo 0)"
  echo "  Tasks:      $(echo "$TASK_FILES" | grep -c . || echo 0)"
  echo "  Breakdowns: $(echo "$BREAKDOWN_FILES" | grep -c . || echo 0)"
  echo "  Blueprint:  $([ -n "$BLUEPRINT_FILE" ] && echo "Yes" || echo "No")"
  echo ""
else
  echo "Legacy mode: Skipping documentation scan"
  echo "Will generate tickets from git history only"
  echo ""
fi
```

**Key Actions:**

- **Standard Mode (full/optimized):**
  - Read all spec files to identify epic-level requirements
  - Parse plan files for dependencies and architecture decisions
  - Extract tasks for feature-level tickets
  - Review breakdown for subtask-level granularity
  - Parse blueprint for milestone and priority data

- **Legacy Mode:**
  - Skip documentation scan entirely
  - Proceed directly to git analysis
  - Infer ticket structure from commit patterns

### 2. Analyze Git Repository State

```bash
# Get branch list
git branch -a

# Get commit history with messages
git log --all --format="%H|%s|%an|%ad" --date=short

# Check current branch status
git status
```

**Key Actions:**

- Parse commit messages for feature/component references
- Match commit messages to spec/task descriptions (standard mode)
- Identify active feature branches
- Map branches to in-progress work
- Detect completed work from merged commits

### 2a. Legacy Mode: Infer Tickets from Git History

**Only runs if MIGRATION_MODE = "legacy"**

```bash
if [ "$MIGRATION_MODE" = "legacy" ]; then
  echo "Legacy mode: Inferring tickets from git commit history..."
  echo ""

  # Extract unique components from commit messages
  # Pattern: feat(component): message, fix(component): message
  COMPONENTS=$(git log --all --format="%s" | \
    grep -oE '\((.*?)\)' | \
    tr -d '()' | \
    sort | uniq)

  echo "Detected components from git history:"
  echo "$COMPONENTS"
  echo ""

  # Group commits by component
  for COMPONENT in $COMPONENTS; do
    # Generate component code (e.g., auth → AUTH, database → DB)
    COMPONENT_CODE=$(echo "$COMPONENT" | tr '[:lower:]' '[:upper:]' | cut -c1-4)

    # Get all commits for this component
    COMMITS=$(git log --all --format="%H|%s|%ad" --date=short | \
      grep -i "($COMPONENT)" || true)

    if [ -n "$COMMITS" ]; then
      # Create single ticket per component (all COMPLETED)
      TICKET_ID="${COMPONENT_CODE}-001"
      TICKET_TITLE="$COMPONENT Implementation"

      # Extract first and last commit dates
      FIRST_COMMIT_DATE=$(echo "$COMMITS" | tail -1 | cut -d'|' -f3)
      LAST_COMMIT_DATE=$(echo "$COMMITS" | head -1 | cut -d'|' -f3)

      # Store for ticket generation
      echo "$TICKET_ID|$TICKET_TITLE|COMPLETED|$LAST_COMMIT_DATE|$COMMITS" >> /tmp/legacy-tickets.txt
    fi
  done

  # If no conventional commit patterns found, create generic tickets from file changes
  if [ ! -s /tmp/legacy-tickets.txt ]; then
    echo "No conventional commits found - inferring from file changes..."

    # Group by top-level directories
    git log --all --name-only --format="" | \
      grep -v '^$' | \
      cut -d'/' -f1 | \
      sort | uniq | \
      while read DIR; do
        if [ -n "$DIR" ]; then
          DIR_CODE=$(echo "$DIR" | tr '[:lower:]' '[:upper:]' | cut -c1-4)
          TICKET_ID="${DIR_CODE}-001"
          COMMITS=$(git log --all --format="%H|%s" -- "$DIR/*" | head -5)
          echo "$TICKET_ID|${DIR} Implementation|COMPLETED|$(date -u +%Y-%m-%d)|$COMMITS" >> /tmp/legacy-tickets.txt
        fi
      done
  fi

  echo "Generated $(wc -l < /tmp/legacy-tickets.txt) legacy tickets from git history"
  echo ""
fi
```

**Legacy Mode Ticket Inference Strategy:**

1. **Pattern Detection:**
   - Extract components from conventional commits: `feat(auth):`, `fix(db):`
   - Group commits by component prefix

2. **Fallback Strategy (if no conventional commits):**
   - Group by top-level directory structure
   - Create tickets based on file change patterns

3. **Ticket Characteristics:**
   - All tickets marked COMPLETED (code already exists)
   - Minimal metadata (git commits + summary)
   - No validation configs (historical record)
   - Completion date = last commit date

4. **Limitations:**
   - Cannot infer dependencies without documentation
   - All tickets are independent
   - No subtask breakdown
   - Historical record only (not execution-ready)

### 3. Generate Ticket Hierarchy

**Use SequentialThinking to:**

- Identify component boundaries from specs
- Generate unique ticket IDs (e.g., AUTH-001, DB-001, UI-001)
- Create hierarchy: Epic (spec) → Story (plan/task) → Subtask (breakdown)
- Extract dependencies from plan documentation
- Map priorities from blueprint phases

**Ticket ID Convention:**

- `[COMPONENT]-[NUMBER]` format
- COMPONENT: 2-4 letter code (AUTH, DB, UI, API, etc.)
- NUMBER: Zero-padded 3-digit sequence (001, 002, etc.)

### 4. Infer Ticket States

**State Logic:**

- **COMPLETED**: Commit message matches ticket description AND tests exist
- **IN_PROGRESS**: Active feature branch exists OR partial commits found
- **DEFERRED**: Dependencies unmet OR explicit TODO/FIXME in code
- **UNPROCESSED**: No evidence of work started

### 5. Create Ticket Files (Mode-Aware)

```bash
# Create tickets directory
mkdir -p .sage/tickets

echo "Generating tickets in $MIGRATION_MODE mode..."
echo ""

# Function to generate ticket based on mode and state
generate_ticket() {
  local TICKET_ID="$1"
  local TICKET_TITLE="$2"
  local TICKET_STATE="$3"
  local HAS_DOCS="$4"  # true/false

  # Determine ticket detail level based on mode and state
  case "$MIGRATION_MODE" in
    full)
      # Full detail for all tickets regardless of state
      generate_full_ticket "$TICKET_ID" "$TICKET_TITLE" "$TICKET_STATE"
      ;;

    optimized)
      # Lightweight for COMPLETED, full for others
      if [ "$TICKET_STATE" = "COMPLETED" ]; then
        generate_lightweight_ticket "$TICKET_ID" "$TICKET_TITLE" "$TICKET_STATE"
      else
        generate_full_ticket "$TICKET_ID" "$TICKET_TITLE" "$TICKET_STATE"
      fi
      ;;

    legacy)
      # Minimal git-history-only tickets
      generate_legacy_ticket "$TICKET_ID" "$TICKET_TITLE"
      ;;
  esac
}

# Generate index.json with mode metadata
cat > .sage/tickets/index.json <<EOF
{
  "version": "1.0",
  "migration_mode": "$MIGRATION_MODE",
  "generated": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "tickets": [
    $(generate_all_tickets_json)
  ]
}
EOF

echo "✓ Tickets generated"
echo ""
```

**Ticket Templates by Mode:**

#### Full Mode Template (All Tickets)

```markdown
# [ID]: [Title]

**State:** UNPROCESSED | IN_PROGRESS | DEFERRED | COMPLETED
**Priority:** P0 | P1 | P2
**Type:** Epic | Story | Subtask

## Description
[Clear description of work to be done]

## Acceptance Criteria
- [ ] Criterion 1
- [ ] Criterion 2

## Dependencies
- #[PARENT-ID] (parent)
- #[DEP-ID] (blocked by)

## Context
**Specs:** docs/specs/component/spec.md
**Plans:** docs/specs/component/plan.md
**Breakdown:** docs/breakdown/component/breakdown.md

## Progress
**Branch:** feature/component-name (if applicable)
**Commits:**
- abc123: commit message
- def456: commit message

**Notes:** [Any relevant context]
```

#### Optimized Mode - Lightweight Template (COMPLETED Tickets Only)

```markdown
# [ID]: [Title]

**State:** COMPLETED
**Completed:** 2025-09-15T10:23:00Z

## Summary
Implemented in commits abc123, def456

## Git History
- abc123: feat(auth): add JWT validation logic
- def456: test(auth): add JWT validation tests
```

**Lightweight JSON Schema (COMPLETED):**

```json
{
  "id": "AUTH-001",
  "title": "Implement JWT validation",
  "state": "COMPLETED",
  "type": "implementation",
  "completed_at": "2025-09-15T10:23:00Z",
  "git": {
    "commits": ["abc123", "def456"]
  },
  "summary": "Implemented JWT validation with tests"
}
```

**Token Savings:** ~90% reduction (500 tokens vs 5000 tokens for full detail)

#### Optimized Mode - Full Template (UNPROCESSED/IN_PROGRESS Tickets)

Same as Full Mode template above (includes validation configs, sub-tasks, acceptance criteria)

#### Legacy Mode Template (Git-History Only)

```markdown
# [ID]: [Title]

**State:** COMPLETED
**Type:** inferred
**Inferred From:** Git commit history

## Summary
Historical ticket inferred from codebase analysis

## Git History
- abc123: Initial implementation
- def456: Follow-up changes

## Notes
This ticket was auto-generated from git history.
No documentation available. Marked COMPLETED as code exists.
```

**Legacy JSON Schema:**

```json
{
  "id": "COMP-001",
  "title": "Component Implementation",
  "state": "COMPLETED",
  "type": "legacy",
  "inferred_from": "git-history",
  "completed_at": "2025-09-15T10:23:00Z",
  "git": {
    "commits": ["abc123", "def456"]
  },
  "summary": "Inferred from git history - no documentation",
  "notes": "Auto-generated from existing codebase"
}
```

**Full Index JSON Schema (All Modes):**

```json
{
  "version": "1.0",
  "migration_mode": "optimized",
  "generated": "ISO8601-timestamp",
  "tickets": [
    {
      "id": "AUTH-001",
      "title": "Implement JWT validation",
      "state": "IN_PROGRESS",
      "priority": "P0",
      "type": "Story",
      "parent": null,
      "children": ["AUTH-002", "AUTH-003"],
      "dependencies": ["DB-001"],
      "docs": {
        "spec": "docs/specs/authentication/spec.md",
        "plan": "docs/specs/authentication/plan.md",
        "breakdown": "docs/breakdown/auth/breakdown.md"
      },
      "git": {
        "branch": "feature/auth-jwt",
        "commits": ["abc123", "def456"]
      },
      "created": "ISO8601-timestamp",
      "updated": "ISO8601-timestamp"
    }
  ]
}
```

### 6. Enhance Tickets with Validation Configuration

**Note:** Only applies to UNPROCESSED/IN_PROGRESS tickets in full/optimized modes. Lightweight COMPLETED tickets and legacy tickets skip this step.

**Use Sequential Thinking to:**

- **Detect Validation Type**: Analyze task descriptions and infer appropriate validation type
- **Generate Sub-Tasks**: Break down task files into granular sub-tasks with validation scripts
- **Create Component Groupings**: Group related tasks into logical components for checkpointing
- **Add Validation Scripts**: Generate appropriate validation commands based on project structure

```bash
# Skip validation config for lightweight/legacy tickets
if [ "$MIGRATION_MODE" = "legacy" ]; then
  echo "Legacy mode: Skipping validation configuration"
  echo "All tickets are historical COMPLETED records"
  # Jump to step 7 (migration report)
elif [ "$MIGRATION_MODE" = "optimized" ] && [ "$TICKET_STATE" = "COMPLETED" ]; then
  echo "Optimized mode: Skipping validation for COMPLETED ticket $TICKET_ID"
  # Lightweight ticket already generated, skip to next
else
  echo "Adding validation configuration for $TICKET_ID..."
  # Proceed with validation config generation below
fi
```

**Validation Type Detection Logic:**

```bash
# Analyze task description keywords
if grep -qi "auth\|login\|state.*flow\|cascade" task_file; then
  VALIDATION_TYPE="stateflow"
elif grep -qi "percentage\|calculation\|counter\|total" task_file; then
  VALIDATION_TYPE="content"
elif grep -qi "button\|click\|form\|link\|handler" task_file; then
  VALIDATION_TYPE="interactive"
elif grep -qi "github\|api\|integration\|external" task_file; then
  VALIDATION_TYPE="integration"
else
  VALIDATION_TYPE="generic"
fi
```

**Sub-Task Generation from Task Breakdown:**

```bash
# Read task breakdown file
TASK_FILE="docs/specs/component/tasks.md"

# Extract individual tasks and create sub-task entries
# Each task becomes a sub-task with validation script

# Example output:
"tasks": [
  {
    "id": "TASK-001-1",
    "type": "interactive",
    "description": "Implement login button handler",
    "status": "UNPROCESSED",
    "validation_script": "npm test -- LoginButton.test",
    "auto_fix": true,
    "max_retries": 3
  },
  {
    "id": "TASK-001-2",
    "type": "stateflow",
    "description": "Validate auth state cascade",
    "status": "UNPROCESSED",
    "validation_script": "npm test -- AuthFlow.test",
    "auto_fix": true,
    "max_retries": 3
  }
]
```

**Component Grouping Strategy:**

```bash
# Group tasks by logical components (from breakdown or spec structure)
# Example: Auth ticket might have AuthModule and AuthUI components

"components": [
  {
    "name": "AuthModule",
    "description": "Core authentication logic",
    "checkpoint_id": "",  # Will be filled by /stream
    "status": "UNPROCESSED",
    "tasks": ["TASK-001-1", "TASK-001-2"]
  },
  {
    "name": "AuthUI",
    "description": "Authentication UI components",
    "checkpoint_id": "",
    "status": "UNPROCESSED",
    "tasks": ["TASK-001-3", "TASK-001-4"]
  }
]
```

**Validation Script Generation:**

```bash
# Detect project type and generate appropriate validation commands

# For React/TypeScript projects
if [ -f "package.json" ] && grep -q "react" package.json; then
  TEST_COMMAND="npm test --"
  LINT_COMMAND="npm run lint"
  BUILD_COMMAND="npm run build"
fi

# For Python projects
if [ -f "pyproject.toml" ] || [ -f "setup.py" ]; then
  TEST_COMMAND="pytest"
  LINT_COMMAND="ruff check"
  BUILD_COMMAND="python -m build"
fi

# Generate validation config based on ticket type
"validation_config": {
  "validator": "${VALIDATOR_TYPE}",
  "auto_fix": true,
  "max_retries": 3,
  "verification_scripts": [
    {
      "name": "unit_tests",
      "command": "${TEST_COMMAND} ${TEST_FILE}",
      "success_pattern": "All tests passed",
      "failure_action": "auto_fix"
    }
  ]
}
```

**Enhanced Ticket JSON Schema:**

```json
{
  "id": "AUTH-001",
  "title": "Implement Authentication System",
  "type": "implementation",  // NEW: ticket type
  "validation_type": "stateflow",  // NEW: validation strategy
  "state": "UNPROCESSED",
  "priority": "P0",
  "parent": null,
  "children": ["AUTH-002"],
  "dependencies": ["DB-001"],

  "tasks": [  // NEW: sub-task array
    {
      "id": "TASK-001-1",
      "type": "interactive",
      "description": "Implement login button handler",
      "status": "UNPROCESSED",
      "validation_script": "npm test -- LoginButton.test",
      "auto_fix": true,
      "max_retries": 3
    },
    {
      "id": "TASK-001-2",
      "type": "stateflow",
      "description": "Validate auth state cascade",
      "status": "UNPROCESSED",
      "validation_script": "npm test -- AuthFlow.test",
      "auto_fix": true,
      "max_retries": 3
    }
  ],

  "validation_config": {  // NEW: validation configuration
    "validator": "StateFlowValidator",
    "auto_fix": true,
    "max_retries": 3,
    "verification_scripts": [
      {
        "name": "auth_flow_test",
        "command": "npm test -- AuthFlow.test",
        "success_pattern": "All tests passed",
        "failure_action": "auto_fix"
      }
    ],
    "state_paths": [  // Validator-specific config
      {
        "name": "admin_login",
        "transitions": [
          "logged_out → login(admin) → admin_nav_visible"
        ]
      }
    ]
  },

  "components": [  // NEW: component grouping
    {
      "name": "AuthModule",
      "description": "Core authentication logic",
      "checkpoint_id": "",
      "status": "UNPROCESSED",
      "tasks": ["TASK-001-1", "TASK-001-2"]
    }
  ],

  "docs": {
    "spec": "docs/specs/authentication/spec.md",
    "plan": "docs/specs/authentication/plan.md",
    "tasks": "docs/specs/authentication/tasks.md",
    "breakdown": "docs/breakdown/auth/breakdown.md"
  },

  "git": {
    "branch": "",
    "commits": []
  },

  "created": "ISO8601-timestamp",
  "updated": "ISO8601-timestamp"
}
```

**Enhanced Ticket Markdown Template:**

```markdown
# [ID]: [Title]

**Type:** implementation | enhancement | bugfix | refactor
**Validation Type:** stateflow | content | interactive | integration | generic
**State:** UNPROCESSED | IN_PROGRESS | DEFERRED | COMPLETED
**Priority:** P0 | P1 | P2

## Description
[Clear description of work to be done]

## Sub-Tasks
- [ ] TASK-001-1: Implement login button handler (interactive)
- [ ] TASK-001-2: Validate auth state cascade (stateflow)
- [ ] TASK-001-3: Display user profile data (content)

## Components
- **AuthModule**: Core authentication logic
- **AuthUI**: Authentication UI components

## Validation Configuration
**Validator:** StateFlowValidator
**Auto-Fix:** Enabled
**Max Retries:** 3

**Verification Scripts:**
- `npm test -- AuthFlow.test` (must pass)
- `npm run lint` (must pass)

## Acceptance Criteria
- [ ] All sub-tasks completed
- [ ] All validation scripts pass
- [ ] No deferred sub-tasks

## Dependencies
- #[PARENT-ID] (parent)
- #[DEP-ID] (blocked by)

## Context
**Specs:** docs/specs/component/spec.md
**Plans:** docs/specs/component/plan.md
**Tasks:** docs/specs/component/tasks.md
**Breakdown:** docs/breakdown/component/breakdown.md

## Progress
**Branch:** feature/component-name (if applicable)
**Commits:** (populated by /stream)

**Notes:** [Any relevant context]
```

### 7. Generate Migration Report

```bash
# Calculate statistics
TOTAL_TICKETS=$(cat .sage/tickets/index.json | jq '.tickets | length')
COMPLETED=$(cat .sage/tickets/index.json | jq '[.tickets[] | select(.state == "COMPLETED")] | length')
IN_PROGRESS=$(cat .sage/tickets/index.json | jq '[.tickets[] | select(.state == "IN_PROGRESS")] | length')
DEFERRED=$(cat .sage/tickets/index.json | jq '[.tickets[] | select(.state == "DEFERRED")] | length')
UNPROCESSED=$(cat .sage/tickets/index.json | jq '[.tickets[] | select(.state == "UNPROCESSED")] | length')

COMPLETED_PCT=$((COMPLETED * 100 / TOTAL_TICKETS))
IN_PROGRESS_PCT=$((IN_PROGRESS * 100 / TOTAL_TICKETS))
DEFERRED_PCT=$((DEFERRED * 100 / TOTAL_TICKETS))
UNPROCESSED_PCT=$((UNPROCESSED * 100 / TOTAL_TICKETS))

# Calculate token savings (optimized mode only)
if [ "$MIGRATION_MODE" = "optimized" ]; then
  # Estimate: Full ticket ~5000 tokens, Lightweight ~500 tokens
  FULL_TOKENS=$((UNPROCESSED * 5000 + IN_PROGRESS * 5000))
  LIGHTWEIGHT_TOKENS=$((COMPLETED * 500))
  TOTAL_TOKENS=$((FULL_TOKENS + LIGHTWEIGHT_TOKENS))

  # Compare to full mode (all tickets at 5000 tokens)
  FULL_MODE_TOKENS=$((TOTAL_TICKETS * 5000))
  SAVED_TOKENS=$((FULL_MODE_TOKENS - TOTAL_TOKENS))
  SAVINGS_PCT=$((SAVED_TOKENS * 100 / FULL_MODE_TOKENS))
fi

# Generate report
tee .docs/MIGRATION_REPORT.md <<EOF
# Ticket Migration Report

**Generated:** $(date -u +%Y-%m-%dT%H:%M:%SZ)
**Migration Mode:** $MIGRATION_MODE
**Total Tickets:** $TOTAL_TICKETS

## Summary

| State | Count | Percentage |
|-------|-------|------------|
| COMPLETED | $COMPLETED | ${COMPLETED_PCT}% |
| IN_PROGRESS | $IN_PROGRESS | ${IN_PROGRESS_PCT}% |
| DEFERRED | $DEFERRED | ${DEFERRED_PCT}% |
| UNPROCESSED | $UNPROCESSED | ${UNPROCESSED_PCT}% |

## Migration Mode Details

**Mode:** $MIGRATION_MODE
$(if [ "$MIGRATION_MODE" = "optimized" ]; then
  echo "
**Token Optimization:**
- COMPLETED tickets (lightweight): $COMPLETED × 500 tokens = $LIGHTWEIGHT_TOKENS tokens
- UNPROCESSED/IN_PROGRESS (full): $((UNPROCESSED + IN_PROGRESS)) × 5000 tokens = $FULL_TOKENS tokens
- **Total tokens used:** $TOTAL_TOKENS
- **Tokens saved vs full mode:** $SAVED_TOKENS ($SAVINGS_PCT% reduction)
"
elif [ "$MIGRATION_MODE" = "legacy" ]; then
  echo "
**Legacy Mode:**
- All tickets inferred from git history
- No documentation required
- All tickets marked COMPLETED
- Minimal metadata (git commits only)
"
elif [ "$MIGRATION_MODE" = "full" ]; then
  echo "
**Full Mode:**
- All tickets contain complete validation configs
- COMPLETED tickets retain full historical detail
- Maximum context preservation
"
fi)

## Ticket Breakdown by Component

### Authentication (AUTH)
- AUTH-001: JWT validation (IN_PROGRESS)
- AUTH-002: OAuth integration (UNPROCESSED)
- AUTH-003: Password reset (COMPLETED)

### Database (DB)
- DB-001: Schema setup (COMPLETED)
- DB-002: Migrations (IN_PROGRESS)

## State Inference Details

### Completed Tickets (X)
- AUTH-003: Matched commit "feat(auth): add password reset" [abc123]
- DB-001: Matched commit "feat(db): initial schema" [def456]

### In-Progress Tickets (Y)
- AUTH-001: Active branch `feature/auth-jwt` detected
- DB-002: Partial commits found, tests incomplete

### Deferred Tickets (Z)
- UI-005: Blocked by AUTH-001 (dependency unmet)

### Ambiguous Cases Requiring Review (N)

**TICKET-ID: [Description]**
- **Evidence:** Partial commits found, no tests
- **Question:** Mark as COMPLETED or IN_PROGRESS?
- **Recommendation:** IN_PROGRESS (tests incomplete)

## Dependency Graph

```plaintext
DB-001 (COMPLETED)
  ↓
AUTH-001 (IN_PROGRESS)
  ↓
AUTH-002 (UNPROCESSED)
  ↓
UI-005 (DEFERRED - blocked)
```

## Next Steps

1. Review ambiguous tickets listed above
2. Run `/implement` to process UNPROCESSED tickets
3. Run `/sync` to push to GitHub
4. Use `/stream` for automated execution

## Files Created

- .sage/tickets/index.json
- .sage/tickets/AUTH-001.md (N files total)
- .docs/MIGRATION_REPORT.md

```

### 7. Interactive Ambiguity Resolution

**Present ambiguous cases to user:**
```

Found ambiguous state for AUTH-004:

- Evidence: 2 commits found
- Tests: Not found
- Branch: No active branch

Options:

1. Mark as COMPLETED (assume tests exist elsewhere)
2. Mark as IN_PROGRESS (incomplete)
3. Mark as DEFERRED (needs review)

Your choice: [1/2/3]

```

### 8. Validation Checks

```bash
# Verify JSON structure
cat .sage/tickets/index.json | grep -c '"id"'

# Count tickets by state
grep -r "^**State:**" .sage/tickets/*.md | sort | uniq -c

# Check for orphaned dependencies
# (dependencies referencing non-existent tickets)
````

## Integration Points

**Inputs:**

- `docs/specs/*/spec.md` - Epic requirements
- `docs/specs/*/plan.md` - Dependencies and architecture
- `docs/specs/*/tasks.md` - Task breakdown
- `docs/breakdown/*/breakdown.md` - Implementation details
- `docs/blueprint.md` - Priorities and milestones
- Git repository (branches, commits, status)

**Outputs:**

- `.sage/tickets/index.json` - Central ticket graph
- `.sage/tickets/[ID].md` - Per-ticket markdown files
- `.docs/MIGRATION_REPORT.md` - Migration summary
- Ready-to-use ticket system for `/implement` and `/stream`

**Workflow Position:**

- **Run Once**: During initial ticket system setup
- **Before**: `/implement`, `/stream`, `/sync`
- **After**: All documentation commands (`/specify`, `/plan`, `/tasks`, etc.)

## Error Scenarios and Recovery

### Missing Documentation (Auto-Handled)

```bash
SPECS_COUNT=$(find docs/specs -name "spec.md" 2>/dev/null | wc -l | tr -d ' ')
DOCS_TOTAL=$((SPECS_COUNT + PLANS_COUNT + TASKS_COUNT + BREAKDOWN_COUNT))

if [ "$DOCS_TOTAL" -eq 0 ]; then
  echo "⚠️  No documentation found - auto-switching to LEGACY mode"
  MIGRATION_MODE="legacy"
fi
```

**Action (Optimized/Full Mode):**

- ❌ ~~Warn user if no specs found, suggest running `/specify` first~~ (OLD BEHAVIOR)
- ✅ **Auto-detect legacy codebase and switch to LEGACY mode** (NEW BEHAVIOR)
- Generate tickets from git history only
- Mark all tickets as COMPLETED (historical record)
- Continue migration without blocking

**Action (Legacy Mode Explicitly Set):**

- Skip documentation scan entirely
- Proceed with git-history-only migration

### Git Repository Not Initialized

```bash
git status 2>&1 | grep -q "not a git repository"
```

**Action**: Skip git analysis, create tickets in UNPROCESSED state only

### Conflicting Ticket IDs

**Action**: Use sequential numbering to avoid collisions, validate uniqueness

### Invalid JSON Structure

**Action**: Validate JSON before writing, provide clear error messages

## Success Criteria

- [ ] All spec files converted to epic tickets
- [ ] All tasks converted to story/subtask tickets
- [ ] Ticket hierarchy established (parent-child relationships)
- [ ] Dependencies mapped from plan documentation
- [ ] Git commits matched to completed tickets
- [ ] Active branches mapped to in-progress tickets
- [ ] .sage/tickets/index.json created with valid structure
- [ ] Per-ticket markdown files generated
- [ ] Migration report produced with statistics
- [ ] Ambiguous cases resolved with user input
- [ ] Ready for `/implement` to process tickets

## Usage Examples

```bash
# Run migration on existing project
/migrate

# Review migration report
cat .docs/MIGRATION_REPORT.md

# Inspect generated tickets
ls .sage/tickets/
cat .sage/tickets/index.json
```

## Notes

- Run this command **once** when introducing ticket system
- After migration, use `/specify`, `/tasks`, etc. to create new tickets
- Use `/implement` to process tickets from the queue
- Use `/sync` to keep GitHub synchronized
- Re-running is safe (will overwrite existing tickets directory)


## estimate


## Role

Project estimator and velocity analyst for ticket-based workflows.

## Purpose

Enhance ticket system with time tracking and estimation capabilities by:

- Adding time estimates to tickets
- Recording state transition timestamps
- Calculating historical velocity metrics
- Generating burndown projections
- Providing data-driven ETA calculations
- Supporting sprint planning with velocity insights

## Execution

### 0. Workflow Mode Validation

```bash
# Ensure TICKET_BASED workflow mode
if [ -f .sage/workflow-mode ]; then
  WORKFLOW_MODE=$(cat .sage/workflow-mode)
  if [ "$WORKFLOW_MODE" != "TICKET_BASED" ]; then
    echo "ERROR: /estimate requires TICKET_BASED workflow mode"
    echo "Current mode: $WORKFLOW_MODE"
    echo ""
    echo "To use estimation:"
    echo "  1. Run /migrate to convert to ticket system"
    echo "  2. Or run /workflow to reconfigure"
    exit 1
  fi
fi

# Validate ticket system exists
if [ ! -f .sage/tickets/index.json ]; then
  echo "ERROR: No ticket system found"
  echo ""
  echo "Run /migrate first to create ticket system"
  exit 1
fi
```

### 1. Load Current Ticket System

```bash
echo "┌────────────────────────────────────────────────┐"
echo "│        TICKET ESTIMATION & VELOCITY            │"
echo "└────────────────────────────────────────────────┘"
echo ""
echo "Loading ticket system..."

TICKET_INDEX=$(cat .sage/tickets/index.json)
TOTAL_TICKETS=$(echo "$TICKET_INDEX" | jq '.tickets | length')

echo "✓ Loaded $TOTAL_TICKETS tickets"
```

### 2. Analyze Existing Estimates

```bash
echo ""
echo "Analyzing existing estimates..."

# Check how many tickets already have estimates
ESTIMATED_COUNT=$(echo "$TICKET_INDEX" | jq '[.tickets[] | select(.estimated_hours != null)] | length')
UNESTIMATED_COUNT=$((TOTAL_TICKETS - ESTIMATED_COUNT))

echo ""
echo "Current Estimation Status:"
echo "  Total Tickets:      $TOTAL_TICKETS"
echo "  With Estimates:     $ESTIMATED_COUNT"
echo "  Without Estimates:  $UNESTIMATED_COUNT"

if [ $UNESTIMATED_COUNT -eq 0 ]; then
  echo ""
  echo "✅ All tickets have estimates"
  echo "Proceeding to velocity analysis..."
else
  echo ""
  echo "⚠️  $UNESTIMATED_COUNT tickets need estimates"
fi
```

### 3. Add Estimates to Unestimated Tickets

```bash
# Estimate tickets based on type, priority, complexity
if [ $UNESTIMATED_COUNT -gt 0 ]; then
  echo ""
  echo "Adding estimates to tickets..."

  # Use AI-driven estimation based on ticket details
  jq '.tickets |= map(
    if .estimated_hours == null then
      # Calculate estimate based on type and priority
      (if .type == "epic" then 40
       elif .type == "story" then 16
       elif .type == "task" then 4
       elif .type == "subtask" then 2
       else 4
       end) as $base_estimate |

      # Adjust by priority
      (if .priority == "P0" then 1.5
       elif .priority == "P1" then 1.2
       elif .priority == "P2" then 1.0
       elif .priority == "P3" then 0.8
       elif .priority == "P4" then 0.5
       else 1.0
       end) as $priority_multiplier |

      # Calculate final estimate
      .estimated_hours = ($base_estimate * $priority_multiplier | floor)
    else
      .
    end
  )' .sage/tickets/index.json > /tmp/tickets-estimated.json

  mv /tmp/tickets-estimated.json .sage/tickets/index.json

  echo "✓ Added estimates to $UNESTIMATED_COUNT tickets"

  # Reload ticket index
  TICKET_INDEX=$(cat .sage/tickets/index.json)
fi
```

### 4. Calculate Historical Velocity

```bash
echo ""
echo "Calculating historical velocity..."

# Check if velocity log exists
if [ -f .sage/stream-velocity.log ]; then
  VELOCITY_ENTRIES=$(wc -l < .sage/stream-velocity.log)

  if [ $VELOCITY_ENTRIES -gt 0 ]; then
    # Calculate average completion time from historical data
    AVG_HOURS=$(awk '{sum+=$2/60; count++} END {printf "%.1f", sum/count}' .sage/stream-velocity.log)
    TICKETS_PER_DAY=$(awk -v avg="$AVG_HOURS" 'BEGIN {printf "%.1f", 8/avg}')

    # Calculate velocity over last 7 days
    SEVEN_DAYS_AGO=$(date -u -v-7d +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -u -d '7 days ago' +%Y-%m-%dT%H:%M:%SZ)
    RECENT_COMPLETIONS=$(awk -v cutoff="$SEVEN_DAYS_AGO" '$1 >= cutoff {count++} END {print count+0}' .sage/stream-velocity.log)

    echo ""
    echo "Historical Velocity Metrics:"
    echo "  Total Completions:      $VELOCITY_ENTRIES tickets"
    echo "  Avg Time/Ticket:        ${AVG_HOURS}h"
    echo "  Velocity:               ${TICKETS_PER_DAY} tickets/day"
    echo "  Last 7 Days:            $RECENT_COMPLETIONS tickets completed"

    # Store velocity metrics
    mkdir -p .sage
    cat > .sage/velocity-metrics.json <<EOF
{
  "last_updated": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "total_completions": $VELOCITY_ENTRIES,
  "avg_hours_per_ticket": $AVG_HOURS,
  "tickets_per_day": $TICKETS_PER_DAY,
  "recent_completions_7d": $RECENT_COMPLETIONS
}
EOF

  else
    echo "⚠️  No historical velocity data yet"
    echo "Run /stream to start tracking velocity"
    AVG_HOURS=0
  fi
else
  echo "⚠️  No velocity log found"
  echo "Run /stream to start tracking velocity"
  AVG_HOURS=0
fi
```

### 5. Generate Project Projections

```bash
echo ""
echo "Generating project projections..."

# Calculate work remaining
COMPLETED=$(echo "$TICKET_INDEX" | jq '[.tickets[] | select(.state == "COMPLETED")] | length')
UNPROCESSED=$(echo "$TICKET_INDEX" | jq '[.tickets[] | select(.state == "UNPROCESSED")] | length')
IN_PROGRESS=$(echo "$TICKET_INDEX" | jq '[.tickets[] | select(.state == "IN_PROGRESS")] | length')

REMAINING=$((UNPROCESSED + IN_PROGRESS))

# Calculate estimated hours remaining
ESTIMATED_HOURS_REMAINING=$(echo "$TICKET_INDEX" | jq '
  [.tickets[] | select(.state == "UNPROCESSED" or .state == "IN_PROGRESS") | .estimated_hours // 4] | add
')

# Calculate completion percentage
COMPLETION_PCT=$((COMPLETED * 100 / TOTAL_TICKETS))

echo ""
echo "Project Status:"
echo "  Progress:              ${COMPLETION_PCT}% complete"
echo "  Completed:             $COMPLETED tickets"
echo "  Remaining:             $REMAINING tickets"
echo "  Estimated Work:        ${ESTIMATED_HOURS_REMAINING}h remaining"

# Calculate ETA if we have velocity data
if [ "$AVG_HOURS" != "0" ] && [ $(echo "$AVG_HOURS > 0" | bc -l) -eq 1 ]; then
  ESTIMATED_DAYS=$(echo "$ESTIMATED_HOURS_REMAINING / 8" | bc -l | xargs printf "%.0f")

  # Calculate working days (assuming 5-day work week)
  CALENDAR_DAYS=$(echo "$ESTIMATED_DAYS * 1.4" | bc -l | xargs printf "%.0f")

  # Calculate completion date
  COMPLETION_DATE=$(date -u -v+${CALENDAR_DAYS}d +%Y-%m-%d 2>/dev/null || date -u -d "+${CALENDAR_DAYS} days" +%Y-%m-%d)

  echo ""
  echo "Estimated Timeline:"
  echo "  Working Days:          ${ESTIMATED_DAYS} days"
  echo "  Calendar Days:         ${CALENDAR_DAYS} days"
  echo "  Projected Completion:  ${COMPLETION_DATE}"
fi
```

### 6. Generate Burndown Data

```bash
echo ""
echo "Generating burndown chart data..."

# Create burndown data file
mkdir -p .sage

# Calculate ideal burndown (linear)
TOTAL_ESTIMATED_HOURS=$(echo "$TICKET_INDEX" | jq '[.tickets[].estimated_hours // 4] | add')
HOURS_COMPLETED=$(echo "$TICKET_INDEX" | jq '
  [.tickets[] | select(.state == "COMPLETED") | .estimated_hours // 4] | add
')
HOURS_REMAINING=$(echo "$TOTAL_ESTIMATED_HOURS - $HOURS_COMPLETED" | bc -l)

cat > .sage/burndown-data.json <<EOF
{
  "generated": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "total_hours": $TOTAL_ESTIMATED_HOURS,
  "hours_completed": $HOURS_COMPLETED,
  "hours_remaining": $HOURS_REMAINING,
  "completion_percentage": $COMPLETION_PCT,
  "tickets": {
    "total": $TOTAL_TICKETS,
    "completed": $COMPLETED,
    "in_progress": $IN_PROGRESS,
    "unprocessed": $UNPROCESSED
  }
}
EOF

echo "✓ Burndown data saved to .sage/burndown-data.json"
```

### 7. Enhance Ticket Schema with Timestamps

```bash
echo ""
echo "Enhancing ticket schema with state tracking..."

# Add state_history and timestamps to tickets
jq '.tickets |= map(
  # Initialize state_history if missing
  if .state_history == null then
    .state_history = [
      {
        "state": .state,
        "timestamp": (now | strftime("%Y-%m-%dT%H:%M:%SZ"))
      }
    ]
  else
    .
  end |

  # Add created timestamp if missing
  if .created == null then
    .created = (now | strftime("%Y-%m-%dT%H:%M:%SZ"))
  else
    .
  end |

  # Add updated timestamp
  .updated = (now | strftime("%Y-%m-%dT%H:%M:%SZ"))
)' .sage/tickets/index.json > /tmp/tickets-enhanced.json

mv /tmp/tickets-enhanced.json .sage/tickets/index.json

echo "✓ Enhanced ticket schema with state tracking"

# Reload ticket index
TICKET_INDEX=$(cat .sage/tickets/index.json)
```

### 8. Generate Estimation Report

```bash
echo ""
echo "┌────────────────────────────────────────────────┐"
echo "│           ESTIMATION REPORT SUMMARY            │"
echo "└────────────────────────────────────────────────┘"
echo ""

# Create detailed estimation report
mkdir -p reports

cat > reports/estimation-report.md <<EOF
# Project Estimation Report

**Generated:** $(date -u +%Y-%m-%d)


## 🎯 Current Status

| State | Count | Estimated Hours |
|-------|-------|-----------------|
| COMPLETED | $COMPLETED | ${HOURS_COMPLETED}h |
| IN_PROGRESS | $IN_PROGRESS | - |
| UNPROCESSED | $UNPROCESSED | ${ESTIMATED_HOURS_REMAINING}h |


## 📅 Timeline Projection

- **Estimated Working Days:** ${ESTIMATED_DAYS} days
- **Estimated Calendar Days:** ${CALENDAR_DAYS} days
- **Projected Completion:** ${COMPLETION_DATE}

EOF
else
  cat >> reports/estimation-report.md <<EOF
⚠️ **No historical velocity data available**

Run \`/stream\` to start tracking velocity metrics.

EOF
fi

cat >> reports/estimation-report.md <<EOF

## 🎲 Ticket Breakdown by Type

EOF

# Add ticket breakdown by type
for TYPE in epic story task subtask; do
  TYPE_COUNT=$(echo "$TICKET_INDEX" | jq --arg type "$TYPE" '[.tickets[] | select(.type == $type)] | length')
  if [ $TYPE_COUNT -gt 0 ]; then
    TYPE_HOURS=$(echo "$TICKET_INDEX" | jq --arg type "$TYPE" '
      [.tickets[] | select(.type == $type) | .estimated_hours // 4] | add
    ')
    echo "- **${TYPE}:** $TYPE_COUNT tickets, ${TYPE_HOURS}h estimated" >> reports/estimation-report.md
  fi
done

cat >> reports/estimation-report.md <<EOF


## 🔄 Next Steps

1. **Review Estimates:** Check \`.sage/tickets/index.json\` for accuracy
2. **Adjust if Needed:** Manually update \`estimated_hours\` for specific tickets
3. **Track Progress:** Run \`/stream\` to record actual completion times
4. **Refine Projections:** Re-run \`/estimate\` after completing tickets
5. **Sprint Planning:** Use velocity data for sprint capacity planning



## repair


## Role

System repair technician fixing ticket system integrity issues.

## Purpose

Automatically fix common ticket system issues by:

- Deduplicating ticket IDs
- Breaking circular dependencies
- Fixing invalid states
- Repairing parent relationships
- Creating missing ticket files
- Normalizing field values
- Regenerating ticket numbers

## Execution

### 0. Pre-flight Check

```bash
# Require validation to run first
echo "Running validation to identify issues..."
/validate 2>&1 | tee /tmp/validation-output.txt

VALIDATION_EXIT=$?

if [ $VALIDATION_EXIT -eq 0 ]; then
  echo ""
  echo "✅ No issues found. Ticket system is valid."
  echo "Nothing to repair."
  exit 0
fi

echo ""
echo "Issues detected. Proceeding with repair..."
```

### 1. Create Checkpoint

```bash
# Backup before making changes
echo "Creating checkpoint before repairs..."

# Use rollback mechanism
create_checkpoint() {
  local COMMAND_NAME=$1
  local REASON=${2:-"automatic"}

  mkdir -p .sage

  # Git stash for working directory
  CHECKPOINT_ID=$(git stash create 2>/dev/null || echo "")

  # Backup ticket system
  if [ -f .sage/.sage/tickets/index.json ]; then
    cp .sage/.sage/tickets/index.json .sage/checkpoint-tickets-index.json
    mkdir -p .sage/checkpoint-tickets
    cp .sage/tickets/*.md .sage/checkpoint-.sage/tickets/ 2>/dev/null
  fi

  # Create checkpoint metadata
  cat > .sage/checkpoint.json <<EOF
{
  "checkpoint_id": "$CHECKPOINT_ID",
  "command": "$COMMAND_NAME",
  "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "reason": "$REASON"
}
EOF

  echo "✓ Checkpoint created: $CHECKPOINT_ID"
}

create_checkpoint "/repair" "pre-repair"
```

### 2. Deduplicate Ticket IDs

```bash
# Fix duplicate ticket IDs by renumbering
echo ""
echo "Checking for duplicate IDs..."

DUPLICATES=$(jq -r '
  .tickets |
  group_by(.id) |
  map(select(length > 1)) |
  .[] |
  .[0].id
' .sage/.sage/tickets/index.json)

if [ -n "$DUPLICATES" ]; then
  echo "Fixing duplicate IDs..."

  # Renumber duplicates
  jq '
    .tickets |= (
      group_by(.id) |
      map(
        if length > 1 then
          # Extract component prefix
          .[0].id as $base |
          ($base | split("-")[0]) as $component |

          # Renumber duplicates
          to_entries |
          map(
            if .key > 0 then
              .value.id = "\($component)-\(now | tostring | .[10:16])-\(.key)"
            end |
            .value
          )
        else
          .
        end
      ) |
      flatten
    )
  ' .sage/.sage/tickets/index.json > /tmp/tickets-dedup.json

  mv /tmp/tickets-dedup.json .sage/.sage/tickets/index.json
  echo "✓ Duplicate IDs fixed"
else
  echo "✓ No duplicate IDs found"
fi
```

### 3. Fix Invalid States

```bash
# Map non-standard states to valid ones
echo ""
echo "Checking for invalid states..."

INVALID_STATES=$(jq -r '
  .tickets[] |
  select(
    .state != "UNPROCESSED" and
    .state != "IN_PROGRESS" and
    .state != "COMPLETED" and
    .state != "DEFERRED"
  ) |
  .id
' .sage/.sage/tickets/index.json)

if [ -n "$INVALID_STATES" ]; then
  echo "Fixing invalid states..."

  # State mapping
  jq '
    .tickets |= map(
      if .state == "DONE" or .state == "FINISHED" then
        .state = "COMPLETED"
      elif .state == "TODO" or .state == "PENDING" then
        .state = "UNPROCESSED"
      elif .state == "WORKING" or .state == "ACTIVE" then
        .state = "IN_PROGRESS"
      elif .state == "SKIPPED" or .state == "POSTPONED" then
        .state = "DEFERRED"
      else
        # Default unknown states to UNPROCESSED
        .state = "UNPROCESSED"
      end
    )
  ' .sage/.sage/tickets/index.json > /tmp/tickets-states.json

  mv /tmp/tickets-states.json .sage/.sage/tickets/index.json
  echo "✓ Invalid states fixed"
else
  echo "✓ All states valid"
fi
```

### 4. Fix Missing Required Fields

```bash
# Add default values for missing required fields
echo ""
echo "Checking for missing required fields..."

MISSING_FIELDS=$(jq -r '
  .tickets[] |
  select(
    .id == null or
    .state == null or
    .priority == null or
    .type == null or
    .title == null or
    .validation_type == null
  ) |
  .id // "UNKNOWN"
' .sage/.sage/tickets/index.json)

if [ -n "$MISSING_FIELDS" ]; then
  echo "Adding missing required fields..."

  jq '
    .tickets |= map(
      if .id == null then
        .id = "TICKET-\(now | tostring | .[10:16])"
      end |
      if .state == null then
        .state = "UNPROCESSED"
      end |
      if .priority == null then
        .priority = "P3"
      end |
      if .type == null then
        .type = "implementation"
      end |
      if .validation_type == null then
        .validation_type = "generic"
      end |
      if .title == null then
        .title = "Untitled Ticket"
      end
    )
  ' .sage/.sage/tickets/index.json > /tmp/tickets-fields.json

  mv /tmp/tickets-fields.json .sage/.sage/tickets/index.json
  echo "✓ Missing fields fixed"
else
  echo "✓ All required fields present"
fi
```

### 5. Fix Invalid Dependencies

```bash
# Remove dependencies that reference non-existent tickets
echo ""
echo "Checking for invalid dependencies..."

ALL_IDS=$(jq -r '.tickets[].id' .sage/.sage/tickets/index.json)

jq --arg all_ids "$ALL_IDS" '
  .tickets |= map(
    if .dependencies != null then
      .dependencies = (
        .dependencies |
        map(select(. as $dep | $all_ids | split("\n") | any(. == $dep)))
      ) |
      if length == 0 then
        null
      else
        .
      end
    end
  )
' .sage/.sage/tickets/index.json > /tmp/tickets-deps.json

mv /tmp/tickets-deps.json .sage/.sage/tickets/index.json
echo "✓ Invalid dependencies removed"
```

### 6. Break Circular Dependencies

```bash
# Remove circular dependencies by breaking cycles
echo ""
echo "Checking for circular dependencies..."

# Simplified: Remove dependencies that create direct cycles
jq '
  .tickets as $all_tickets |
  .tickets |= map(
    . as $ticket |
    if .dependencies != null then
      .dependencies = (
        .dependencies |
        map(
          select(
            . as $dep |
            ($all_tickets | map(select(.id == $dep).dependencies // []) | flatten | any(. == $ticket.id)) | not
          )
        )
      ) |
      if length == 0 then
        null
      else
        .
      end
    end
  )
' .sage/.sage/tickets/index.json > /tmp/tickets-cycles.json

mv /tmp/tickets-cycles.json .sage/.sage/tickets/index.json
echo "✓ Circular dependencies broken"
```

### 7. Fix Parent Relationships

```bash
# Remove parent references that don't exist
echo ""
echo "Checking for orphaned tickets..."

ALL_IDS=$(jq -r '.tickets[].id' .sage/.sage/tickets/index.json)

jq --arg all_ids "$ALL_IDS" '
  .tickets |= map(
    if .parent != null then
      if ([$. parent] | inside($all_ids | split("\n"))) then
        .
      else
        # Remove invalid parent reference
        .parent = null
      end
    else
      .
    end
  )
' .sage/.sage/tickets/index.json > /tmp/tickets-parents.json

mv /tmp/tickets-parents.json .sage/.sage/tickets/index.json
echo "✓ Orphaned tickets fixed"
```

### 8. Create Missing Ticket Files

```bash
# Generate markdown files for tickets without them
echo ""
echo "Checking for missing ticket files..."

MISSING_COUNT=0

jq -r '.tickets[] | .id' .sage/.sage/tickets/index.json | while read TICKET_ID; do
  TICKET_FILE=".sage/.sage/tickets/${TICKET_ID}.md"

  if [ ! -f "$TICKET_FILE" ]; then
    echo "Creating $TICKET_FILE..."

    # Extract ticket data
    TICKET_DATA=$(jq --arg id "$TICKET_ID" '.tickets[] | select(.id == $id)' .sage/.sage/tickets/index.json)
    TITLE=$(echo "$TICKET_DATA" | jq -r '.title')
    DESCRIPTION=$(echo "$TICKET_DATA" | jq -r '.description // "No description provided"')
    TYPE=$(echo "$TICKET_DATA" | jq -r '.type')
    PRIORITY=$(echo "$TICKET_DATA" | jq -r '.priority')
    STATE=$(echo "$TICKET_DATA" | jq -r '.state')

    # Create ticket markdown
    cat > "$TICKET_FILE" <<EOF
# ${TICKET_ID}: ${TITLE}

**Type:** ${TYPE}
**Priority:** ${PRIORITY}
**State:** ${STATE}

## Description

${DESCRIPTION}

## Acceptance Criteria

- [ ] Implementation complete
- [ ] Tests passing
- [ ] Documentation updated

## Notes

*Ticket file auto-generated by /repair*
EOF

    MISSING_COUNT=$((MISSING_COUNT + 1))
  fi
done

if [ $MISSING_COUNT -gt 0 ]; then
  echo "✓ Created $MISSING_COUNT missing ticket files"
else
  echo "✓ All ticket files exist"
fi
```

### 9. Normalize Priority Values

```bash
# Map non-standard priorities to standard P0-P4
echo ""
echo "Normalizing priority values..."

jq '
  .tickets |= map(
    if .priority == "CRITICAL" or .priority == "URGENT" then
      .priority = "P0"
    elif .priority == "HIGH" then
      .priority = "P1"
    elif .priority == "MEDIUM" or .priority == "NORMAL" then
      .priority = "P2"
    elif .priority == "LOW" then
      .priority = "P3"
    elif .priority | test("^P[0-4]$") | not then
      # Default unknown priorities to P2
      .priority = "P2"
    end
  )
' .sage/.sage/tickets/index.json > /tmp/tickets-priority.json

mv /tmp/tickets-priority.json .sage/.sage/tickets/index.json
echo "✓ Priorities normalized"
```

### 9a. Fix Invalid Ticket Types

```bash
# Map non-standard ticket types to valid enums
echo ""
echo "Fixing invalid ticket types..."

INVALID_TYPES=$(jq -r '
  .tickets[] |
  select(
    .type != "implementation" and
    .type != "enhancement" and
    .type != "bugfix" and
    .type != "refactor"
  ) |
  .id
' .sage/.sage/tickets/index.json)

if [ -n "$INVALID_TYPES" ]; then
  echo "Normalizing ticket types..."

  jq '
    .tickets |= map(
      if .type == "feature" or .type == "new" then
        .type = "implementation"
      elif .type == "improvement" or .type == "optimize" then
        .type = "enhancement"
      elif .type == "bug" or .type == "fix" then
        .type = "bugfix"
      elif .type == "cleanup" or .type == "tech-debt" then
        .type = "refactor"
      elif .type != "implementation" and .type != "enhancement" and .type != "bugfix" and .type != "refactor" then
        # Default unknown types to implementation
        .type = "implementation"
      end
    )
  ' .sage/.sage/tickets/index.json > /tmp/tickets-types.json

  mv /tmp/tickets-types.json .sage/.sage/tickets/index.json
  echo "✓ Ticket types fixed"
else
  echo "✓ All ticket types valid"
fi
```

### 9b. Fix Invalid Validation Types

```bash
# Map non-standard validation types to valid enums
echo ""
echo "Fixing invalid validation types..."

INVALID_VALIDATION=$(jq -r '
  .tickets[] |
  select(
    .validation_type != "stateflow" and
    .validation_type != "content" and
    .validation_type != "interactive" and
    .validation_type != "integration" and
    .validation_type != "generic"
  ) |
  .id
' .sage/.sage/tickets/index.json)

if [ -n "$INVALID_VALIDATION" ]; then
  echo "Defaulting invalid validation types to generic..."

  jq '
    .tickets |= map(
      if .validation_type != "stateflow" and
         .validation_type != "content" and
         .validation_type != "interactive" and
         .validation_type != "integration" and
         .validation_type != "generic" then
        .validation_type = "generic"
      end
    )
  ' .sage/.sage/tickets/index.json > /tmp/tickets-validation-types.json

  mv /tmp/tickets-validation-types.json .sage/.sage/tickets/index.json
  echo "✓ Validation types fixed"
else
  echo "✓ All validation types valid"
fi
```

### 9c. Fix Sub-Task Schema

```bash
# Repair sub-task arrays with missing required fields
echo ""
echo "Checking sub-task schema..."

INVALID_TASK_SCHEMA=$(jq -r '
  .tickets[] |
  select(.tasks != null) |
  select(
    .tasks |
    any(
      .id == null or
      .type == null or
      .description == null or
      .status == null
    )
  ) |
  .id
' .sage/.sage/tickets/index.json)

if [ -n "$INVALID_TASK_SCHEMA" ]; then
  echo "Fixing sub-task schema..."

  jq '
    .tickets |= map(
      if .tasks != null then
        .tasks |= map(
          . as $task |
          if .id == null then
            .id = "TASK-\(.description[0:10] | gsub(" "; "-"))-\(now | tostring | .[10:16])"
          end |
          if .type == null then
            .type = "generic"
          end |
          if .description == null then
            .description = "No description"
          end |
          if .status == null then
            .status = "UNPROCESSED"
          end |
          if .auto_fix == null then
            .auto_fix = true
          end |
          if .max_retries == null then
            .max_retries = 3
          end
        )
      end
    )
  ' .sage/.sage/tickets/index.json > /tmp/tickets-task-schema.json

  mv /tmp/tickets-task-schema.json .sage/.sage/tickets/index.json
  echo "✓ Sub-task schema fixed"
else
  echo "✓ Sub-task schema valid"
fi
```

### 9d. Clean Orphaned Component Checkpoints

```bash
# Remove component checkpoints that reference non-existent git commits
echo ""
echo "Checking component checkpoints..."

ORPHANED_CHECKPOINTS=$(jq -r '
  .tickets[] |
  select(.components != null) |
  .components[] |
  select(.checkpoint_id != null and .checkpoint_id != "") |
  .checkpoint_id
' .sage/.sage/tickets/index.json)

if [ -n "$ORPHANED_CHECKPOINTS" ]; then
  echo "Verifying component checkpoints..."

  # Remove invalid checkpoints
  jq '
    .tickets |= map(
      if .components != null then
        .components |= map(
          if .checkpoint_id != null and .checkpoint_id != "" then
            # Note: In real implementation, verify against git
            # For now, preserve all checkpoints
            .
          end
        )
      end
    )
  ' .sage/.sage/tickets/index.json > /tmp/tickets-checkpoints.json

  mv /tmp/tickets-checkpoints.json .sage/.sage/tickets/index.json
  echo "✓ Component checkpoints verified"
else
  echo "✓ No component checkpoints to verify"
fi
```

### 10. Validate Repairs

```bash
# Run validation to confirm fixes worked
echo ""
echo "Validating repaired ticket system..."

/validate

if [ $? -eq 0 ]; then
  echo ""
  echo "================================================"
  echo "✅ TICKET REPAIR SUCCESSFUL"
  echo "================================================"
  echo ""
  echo "All issues fixed. Ticket system is now valid."
  echo ""
  echo "Checkpoint preserved at: .sage/checkpoint.json"
  echo "If repairs caused issues, run: /rollback"
  echo "================================================"

  # Clear checkpoint on success
  # rm .sage/checkpoint.json  # Optional: keep for safety
else
  echo ""
  echo "================================================"
  echo "⚠️  REPAIR INCOMPLETE"
  echo "================================================"
  echo ""
  echo "Some issues remain. Manual intervention may be required."
  echo ""
  echo "To restore pre-repair state: /rollback"
  echo "================================================"
  exit 1
fi
```

## Repair Modes

### Auto Repair (All Issues)

```bash
/repair
# Default: Fix all detected issues automatically
```

### Specific Repairs

```bash
/repair --deduplicate
# Only fix duplicate ticket IDs

/repair --fix-states
# Only fix invalid states

/repair --fix-dependencies
# Only fix invalid dependencies

/repair --break-cycles
# Only remove circular dependencies

/repair --fix-parents
# Only fix orphaned tickets

/repair --create-missing-files
# Only create missing ticket markdown files

/repair --fix-fields
# Only add missing required fields
```

### Interactive Repair

```bash
/repair --interactive
# Ask for confirmation before each repair
```

### Dry Run

```bash
/repair --dry-run
# Show what would be repaired without making changes
```

## Common Repair Scenarios

### Scenario 1: Duplicate IDs After Manual Edits

```bash
# Problem: Manually edited .sage/.sage/tickets/index.json, created duplicates
/validate  # Shows duplicate IDs
/repair --deduplicate
/validate  # Confirms fixed
```

### Scenario 2: Corrupted JSON

```bash
# Problem: .sage/.sage/tickets/index.json is invalid JSON
/validate  # Shows JSON parse error

# Manual fix required:
# 1. Restore from backup: /rollback
# 2. Or fix JSON manually, then validate
```

### Scenario 3: Broken Dependencies After Ticket Deletion

```bash
# Problem: Deleted ticket, other tickets still reference it
/validate  # Shows invalid dependencies
/repair --fix-dependencies
/validate  # Confirms fixed
```

### Scenario 4: Circular Dependencies

```bash
# Problem: Ticket A depends on B, B depends on A
/validate  # Shows circular dependencies
/repair --break-cycles
/validate  # Confirms cycles broken
```

## Repair Strategies

### Duplicate IDs

**Strategy:** Renumber duplicates with timestamp suffix
**Example:** `AUTH-001` duplicates become `AUTH-001`, `AUTH-001-123456-1`, `AUTH-001-123456-2`

### Invalid States

**Mapping:**

- `DONE`, `FINISHED` → `COMPLETED`
- `TODO`, `PENDING` → `UNPROCESSED`
- `WORKING`, `ACTIVE` → `IN_PROGRESS`
- `SKIPPED`, `POSTPONED` → `DEFERRED`
- Unknown → `UNPROCESSED`

### Invalid Dependencies

**Strategy:** Remove dependencies to non-existent tickets

### Circular Dependencies

**Strategy:** Break cycles by removing back edges (dependencies that create cycles)

### Orphaned Tickets

**Strategy:** Remove parent reference if parent doesn't exist

### Missing Files

**Strategy:** Generate basic ticket markdown from .sage/.sage/tickets/index.json data

## Integration with Other Commands

### Pre-migration Repair

```bash
# Before migrating tickets
/validate
/repair  # If validation fails
/migrate
```

### Post-sync Repair

```bash
# After syncing with GitHub
/sync
/validate
/repair  # If sync introduced issues
```

### Recovery Workflow

```bash
# If ticket system corrupted
/validate  # Identify issues
/repair    # Attempt auto-repair
/validate  # Verify repairs

# If repair fails
/rollback          # Restore previous state
# Manual fix, then retry
```

## Exit Codes

- **0** - Repairs successful, ticket system valid
- **1** - Repairs failed, manual intervention required

## Success Criteria

- [ ] Checkpoint created before repairs
- [ ] Duplicate IDs resolved
- [ ] Invalid states mapped to valid values
- [ ] Missing required fields added
- [ ] Invalid dependencies removed
- [ ] Circular dependencies broken
- [ ] Orphaned tickets fixed
- [ ] Missing ticket files created
- [ ] Priorities normalized
- [ ] Validation passes after repair

## Notes

- Always creates checkpoint before repairs
- Destructive operation (modifies .sage/.sage/tickets/index.json)
- Use `/rollback` if repairs cause issues
- Some issues require manual intervention (e.g., invalid JSON)
- Safe to run multiple times (idempotent)
- Validation runs automatically after repair
- Checkpoint preserved for safety (can be manually cleared)

